
function [AEinfMV,AE2MV,beta0MV,lambdaV,XYW,XYWR,JzMV,HzMV,Wg_norm2]=...
    demo_disk(lambda_index,a,sigma,XYW,XYWR)

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Numerical experiment in "Hybrid hyperinterpolation over general regions".
% Region: unit-disk.
%--------------------------------------------------------------------------
% Usage:
% >> demo_disk
%--------------------------------------------------------------------------
% Note:
% The routine uses 'binornd' that requires Statistics and Machine Learning 
% Toolbox.
%--------------------------------------------------------------------------
% Dates:
% Written on January 1, 2023: A. Sommariva.
% Modified on April 22, 2023: A. Sommariva.
%--------------------------------------------------------------------------
% COPYRIGHT
%--------------------------------------------------------------------------
% Copyright (C) 2023- 
%
% Authors:
% Alvise Sommariva
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <https://www.gnu.org/licenses/>.
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------
% Degrees of precision in numerical experiments: can be a vector.
%--------------------------------------------------------------------------

LV=16;        % Hyperinterpolant tot degree.
NV=2*LV;      % Degree of precision of the rule.
NR=100;       % Reference degree of cubature rule.

%--------------------------------------------------------------------------
% Noise and choice of lasso, hybrid, hard thresh. parameter.
%--------------------------------------------------------------------------

% Defining elastic parameter (knowning hyp. coeffs, it is the k-th in 
% descending absolute value!)
if nargin<1,lambda_index=1;end

noise=1;            % 0: no noise, 1: noise (see parameters below)

% In the reference paper of Lasso (Table 1): a=0, sigma=0.2.
if noise
    if nargin <2,a=0;end     % defining impulse noise (in experiment 2)
    if nargin <3,sigma=0.5;end   % defining gaussian noise (in experiment 2)
else
    a=0; sigma=0; % no noise.
end

% * Function to approximate:
% 1. degree L poly., 2. degree floor(L/2)-1 poly. 3. test functions 
% (see line 300 approx).
funct_example=3;  

% No table or stats.
display_stats=0;

%--------------------------------------------------------------------------
% Special settings.
%--------------------------------------------------------------------------

% Plot domain and nodes: do_plot=1 (yes), do_plot=0 (no).
do_plot=0;

% Number of tests for reconstructing functions of a type on this domain.
ntests=100;





% ........................ Main code below ................................



% ........ Numerical approximation, varying the degree in "nV" ............

AEinfMV=[]; AE2MV=[]; beta0MV=[]; % vectors used for statistics
JzMV=[]; HzMV=[];

for k=1:length(NV)
    N=NV(k); % Quadrature points.
    L=LV(k); % Hyperinterpolant degree.

    % Test points
    if nargin < 5, XYWR=cub_disk_productrule(NR); end
    if isempty(XYWR), XYWR=cub_disk_productrule(NR); end
    XR=XYWR(:,1); YR=XYWR(:,2); WR=XYWR(:,3);

    % define quadrature rule for hyperinterpolation at degree N.
    if nargin < 4, XYW=cub_disk_productrule(N); end
    if isempty(XYW), XYW=cub_disk_productrule(N); end
    X=XYW(:,1); Y=XYW(:,2); W=XYW(:,3);

    % Vandermonde matrix at nodes.
    % compute hyperinterpolant coefficients
    [V,degs]=vandermonde_logan_shepp(L,[X Y]);

    % .. testing AE_L2err hyperinterpolation error for each "f" at "deg" ..

    poly_coeffs=[];
    lambdaV=[];

    for j=1:ntests

        % ... define function to approximate ...
        g=define_function(funct_example,L);

        % ... evaluate function to approximate ...
        gXY=feval(g,X,Y);

        % ... Add noise (if present) ...

        % add impulse noise
        pert_impulse=0;
        if a > 0
            pert_impulse=a*(1-2*rand(length(gXY),1))*binornd(1,0.5);
            while norm(pert_impulse) == 0
                pert_impulse=a*(1-2*rand(length(gXY),1))*binornd(1,0.5);
            end
        end

        % add gaussian noise
        pert_gauss=0;
        if sigma > 0
            var=sigma^2;
            pert_gauss=sqrt(var)*randn(size(gXY));
            while norm(pert_gauss) == 0
                pert_gauss=sqrt(var)*randn(size(gXY));
            end
        end

        % add gaussian + impulse noise
        pert=pert_impulse+pert_gauss;

        % perturbed values
        gXY_pert=gXY+pert;

        % ... determine polynomial hyperinterpolant ...
        coeff0=(gXY_pert.*W)'*V; coeff0=coeff0';

        degs=0:L;

        % test hyperinterpolant with or withour filters.

       lambdas=sort(abs(coeff0),'descend');
       lambdaL=lambdas(lambda_index);

        for ktest=1:6
            switch ktest
                case 1
                    hypermode='tikhonov';
                    parms.lambda=lambdaL;
                    parms.mu=[];
                    parms.b=ones(size(coeff0));
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);

                case 2
                    hypermode='filtered';
                    parms.lambda=[];
                    parms.mu=[];
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 3
                    hypermode='lasso';
                    parms.lambda=lambdaL;
                    parms.mu=ones(size(coeff));
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 4
                    hypermode='hybrid';
                    parms.lambda=lambdaL;
                    parms.mu=ones(size(coeff0));
                    parms.b=ones(size(coeff0));
                    parms.w=W;
                    parms.pert=pert;
                    parms.hybrid=0; % establishes it is a pre-choosen parameter.
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
              case 5
                    hypermode='hard';
                    parms.lambda=lambdaL;
                    parms.mu=[];
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 6
                    hypermode='hyperinterpolation';
                    parms.lambda=[];
                    parms.mu=[];
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
            end

            gXYR=feval(g,XR,YR);
            [VR,degs]=vandermonde_logan_shepp(L,[XR YR]);

            pXYR=VR*coeff;

            % errors
            AEinfV(ktest,j)=norm(gXYR-pXYR,inf); % absolute error (inf norm)
            AE2V(ktest,j)=sqrt(WR'*((gXYR-pXYR).^2)); % absolute error (2 norm)
            beta0V(ktest,j)=sum(abs(coeff) > 0);

            JzV(ktest,j)=evaluate_J(coeff,coeff0);
            HzV(ktest,j)=evaluate_H(coeff,W,pert,V);

        end

        lambdaV=[lambdaV lambdas];

    end

    % averages of the errors (vectors 5 x 1)
    AEinfM=mean(AEinfV,2);
    AE2M=mean(AE2V,2);
    beta0M=mean(beta0V,2);
    JzM=mean(JzV,2);
    HzM=mean(HzV,2);

    if display_stats
    fprintf('\n       ........ table at degree: %2.0f ........ \n \n ',N);
    HypType=categorical({'tikhonov'; 'filtered'; 'lasso'; 'hybrid'; ...
        'hard'; 'hyperint.'});
    T = table(HypType,AEinfM,AE2M,beta0M,JzM,HzM); disp(T)
    end
    
    AEinfMV=[AEinfMV AEinfM]; AE2MV=[AE2MV AE2M]; beta0MV=[beta0MV beta0M];
    JzMV=[JzMV JzM]; HzMV=[HzMV HzM];

end

Wg_norm2=(norm(sqrt(W).*gXY,2))^2;











function XYW=cub_disk_productrule(N)

% PRODUCT TYPE RULE ON THE UNIT DISK: ade at least "N". 

n=ceil(N/2);
gaussian_type=1;

switch gaussian_type
    case 1
        % Gaussian rule in [0,1]: ade=2*n -> n+1 points.
        ab=r_jacobi(n+1,0,0); xw=gauss(n+1,ab);
        r0=xw(:,1); wr0=xw(:,2); r=(r0+1)/2; wr=wr0/2;
        %     case 2
        %         xw=lobatto_jacobi(n,0,0); % ADE: 2*n+1 using n+2 points.
        %         r0=xw(:,1); wr0=xw(:,2); r=(r0+1)/2; wr=wr0/2;
        %     case 3
        %         xw=radau_jacobi(n,1,0,0); % ADE: 2*n using n+1 points.
        %         r0=xw(:,1); wr0=xw(:,2); r=(r0+1)/2; wr=wr0/2;
end

% Trapezoidal rule.
m=0:2*n; th=2*pi*m/(2*n+1); th=th';
wth=2*pi*ones(size(th))/(2*n+1);

% Nodes in polar coordinates.
[R,TH]=meshgrid(r,th);
Rv=R(:); THv=TH(:);
X=Rv.*cos(THv); Y=Rv.*sin(THv);

[W1,W2]=meshgrid(wr.*r,wth);
W=W1.*W2; W=W(:);

XYW=[X Y W];






function plot_error_disk(f,coeff,n)

t=-1:0.01:1;
[XR,YR]=meshgrid(t);

fXYR=feval(f,XR,YR);
VR=vandermonde_logan_shepp(n,[XR(:) YR(:)]);
pXYR0=VR*coeff;

pXYR=reshape(pXYR0,size(XR,1),size(XR,2));

val=(ones(size(XR))-XR.^2-YR.^2) >= 0;
err=abs(fXYR-pXYR).*val;

plot3(XR,YR,err);
hold on;
AZ=20; EL=45;
view(AZ,EL);
hold off;







function g=define_function(funct_example,L)

% function to test

switch funct_example

    case 1 % test exactness hyperinterpolation
        nexp=L;
        c0=rand(1); c1=rand(1); c2=rand(1);
        g=@(x,y) (c0+c1*x+c2*y).^nexp;

    case 2 % test exactness filt. hyperinterpolation
        nexp=max(floor(L/2)-1,0);
        c0=rand(1); c1=rand(1); c2=rand(1);
        g=@(x,y) (c0+c1*x+c2*y).^nexp;

    case 3 % function of that type

        %  Test function.

        funct_example_sub=1;

        switch funct_example_sub
            case 1
                g=@(x,y) (1-x.^2-y.^2).*exp(x.*cos(y));
                fstring='(1-x.^2-y.^2).*exp(x.*cos(y))';
            case 2
                g=@(x,y) exp((x.^6).*cos(y));
                fstring='exp((x.^6).*cos(y))';
        end


end







function Jz=evaluate_J(z,alpha)

%--------------------------------------------------------------------------
% Object:
% Evaluate function J(z)=sum( (z(l))^2-2*z(l)*alpha(l) )
%--------------------------------------------------------------------------
% Input:
% z    : vector of dimension d x 1
% alpha: vector of dimension d x 1
%--------------------------------------------------------------------------
% Output:
% Jz: value of J(z)=sum( (z(l))^2-2*z(l)*alpha(l) )
%--------------------------------------------------------------------------
% Reference:
% Quantity relevant in Thm. 5.1 of the paper
% "Hybrid hyperinterpolation over general regions"
% Congpei An · Alvise Sommariva · Jia-Shu Ran
%--------------------------------------------------------------------------

% Jz=sum(z.^2-2*z.*alpha);
Jz=z'*z -2*z'*alpha;




function Hz=evaluate_H(z,w,err,V)

%--------------------------------------------------------------------------
% Object:
% Evaluate function H(z)=2*sum_l( z(l) * sum_j( w(j)*err(j)*V(l,j) ) )
%--------------------------------------------------------------------------
% Input:
% z    : vector of dimension d x 1
% w    : vector of dimension N x 1
% err  : vector of dimension N x 1
% V    : matrix of dimension d x N
%--------------------------------------------------------------------------
% Output:
% Hz: value of H(z)=2*sum_l( z(l) * sum_j( w(j)*err(j)*V(l,j) ) )
%--------------------------------------------------------------------------
% Reference:
% Quantity relevant in Thm. 5.1 of the paper
% "Hybrid hyperinterpolation over general regions"
% Congpei An · Alvise Sommariva · Jia-Shu Ran
%--------------------------------------------------------------------------

inner_term=V'*(w.*err);
outer_term=z'*inner_term;
Hz=2*outer_term;






