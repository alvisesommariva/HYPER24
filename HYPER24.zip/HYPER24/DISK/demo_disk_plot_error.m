function [pert,coeff0,idx_infity,a,sigma]=demo_disk_plot_error
% Author: Jia-Shu Ran
% Date: 15 August, 2023
% demo_interval_plot is used to plot original function
% and its recovery function via different hyperinterpolants
% on the unit-disk

LV=16;        % Hyperinterpolant tot degree.
NV=2*LV;        % Degree of precision of the rule.
NR=100;       % Reference degree of cubature rule.

%--------------------------------------------------------------------------
% Noise and choice of lasso, hybrid, hard thresh. parameter.
%--------------------------------------------------------------------------

% * Function to approximate:
% 1. degree L poly., 2. degree floor(L/2)-1 poly. 3. test functions 
% (see line 300 approx).
funct_example=3;  

AEinfMV=[]; AE2MV=[]; beta0MV=[]; % vectors used for statistics

% Test points
XYWR=cub_disk_productrule(NR); XR=XYWR(:,1); YR=XYWR(:,2); WR=XYWR(:,3);

% define quadrature rule for hyperinterpolation at degree N.
XYW=cub_disk_productrule(NV); X=XYW(:,1); Y=XYW(:,2); W=XYW(:,3);

% Vandermonde matrix at nodes.
% compute hyperinterpolant coefficients
[V,degs]=vandermonde_logan_shepp(LV,[X Y]);

% ... define function to approximate ...
g=define_function(funct_example,LV);

% ... evaluate function to approximate ...
gXY=feval(g,X,Y);

% add impulse noise 
a =0; %pert=a*(1-2*rand(length(gXY),1))*binornd(1,0.5);

sigma = 0.1;

% add gaussian noise
pert = sigma*randn(size(gXY)) + a*(1-2*rand(length(gXY),1))*binornd(1,0.5);

% perturbed values
gXY_pert=gXY+pert;

% ... determine polynomial hyperinterpolant ...
coeff0=(gXY_pert.*W)'*V; coeff0=coeff0';

degs=0:LV;

% we reference to the method in "RBF approximation of noisy scattered data on the sphere"
lambdas = -15:0.1:7;

lambdak=2.^lambdas;

for k = 1:length(lambdas)
lambdaL = lambdak(k);

for ktest=1:6
    switch ktest
        case 1
            hypermode='tikhonov';
            parms.lambda=lambdaL;
            parms.mu=[];
            parms.b=ones(size(coeff0));
            coeff=hyperfilter(hypermode,coeff0,degs,parms);
        case 2
            hypermode='filtered';
            parms.lambda=[];
            parms.mu=[];
            parms.b=[];
            coeff=hyperfilter(hypermode,coeff0,degs,parms);
        case 3
            hypermode='lasso';
            parms.lambda=lambdaL;
            parms.mu=ones(size(coeff));
            parms.b=[];
            coeff=hyperfilter(hypermode,coeff0,degs,parms);
        case 4
            hypermode='hybrid';
            parms.lambda=lambdaL;
            parms.mu=ones(size(coeff0));
            parms.b=ones(size(coeff0));
            parms.w=W;
            parms.pert=pert;
            parms.hybrid=0; % establishes it is a pre-choosen parameter.
            coeff=hyperfilter(hypermode,coeff0,degs,parms);
        case 5
            hypermode='hard';
            parms.lambda=lambdaL;
            parms.mu=[];
            parms.b=[];
            coeff=hyperfilter(hypermode,coeff0,degs,parms);
        case 6
            hypermode='hyperinterpolation';
            parms.lambda=[];
            parms.mu=[];
            parms.b=[];
            coeff=hyperfilter(hypermode,coeff0,degs,parms);
    end

    gXYR=feval(g,XR,YR);
    [VR,degs]=vandermonde_logan_shepp(LV,[XR YR]);

    % evaluate polynomial at reference points.
    pXYR(:,ktest)=VR*coeff;

    % errors
    AEinfV(k,ktest)=norm(gXYR-pXYR(:,ktest),inf); % absolute error (inf norm)
    AE2V(k,ktest)=sqrt(WR'*((gXYR-pXYR(:,ktest)).^2)); % absolute error (2 norm)
    beta0V(k,ktest)=sum(abs(coeff) > 0);

%     [pXYR_re, abs_err] = evaluate_disk(g,coeff,LV);
% 
%     pXYR_re_plot(k,ktest).matrix = pXYR_re;
%     abs_err_plot(k,ktest).matrix = abs_err;

end

end


% hard thresholding hyper.
figure(1)
[xmin_hth, ] = find(AE2V(:,5) == min(AE2V(:,5)));
[xmin_hth_infity, ] = find(AEinfV(:,5) == min(AEinfV(:,5)));

loglog(lambdak,AE2V(:,5),'linewidth',3,'color','blue'), box on, 
set(gca, 'FontSize', 35, 'XMinorGrid', 'on'), set(gca, 'FontSize', 35, 'YMinorGrid', 'on'),
hold on,
loglog(lambdak,AEinfV(:,5),'-.','linewidth',3,'color','black'), box on, 
set(gca, 'FontSize', 35, 'XMinorGrid', 'on'), set(gca, 'FontSize', 35, 'YMinorGrid', 'on'),
loglog(lambdak(xmin_hth),min(AE2V(:,5)),'pentagram','linewidth',2,'MarkerSize',30,'color','red','MarkerFaceColor','red'), hold on,
loglog(lambdak(xmin_hth_infity),min(AEinfV(:,5)),'diamond','linewidth',2,'MarkerSize',30,'color','red','MarkerFaceColor','red'), hold on,


title({'\textbf{Hard thresholding hyperinterpolation}'},'interpreter','latex','fontsize',35);
xlabel({'\textbf{Regularization parameter} $\lambda$'},'interpreter','latex','fontsize',35);
legend({'$L_2$ \textbf{norm of error}','$L_{\infty}$ \textbf{norm of error}',['{\textbf{Minimum at}} $\lambda \in [$',num2str(min(lambdak(xmin_hth))),'$,\:$', num2str(max(lambdak(xmin_hth))),'$]$'],['{\textbf{Minimum at}} $\lambda \in [$',num2str(min(lambdak(xmin_hth_infity))),'$,\:$', num2str(max(lambdak(xmin_hth_infity))),'$]$']},'interpreter','latex','fontsize',40,'Location','northwest');

% lasso hyper.
figure(2)
[xmin_lh, ] = find(AE2V(:,3) == min(AE2V(:,3)));
[xmin_lh_infity, ] = find(AEinfV(:,3) == min(AEinfV(:,3)));

loglog(lambdak,AE2V(:,3),'linewidth',3,'color','blue'), box on, 
set(gca, 'FontSize', 35, 'XMinorGrid', 'on'), set(gca, 'FontSize', 35, 'YMinorGrid', 'on'),
hold on,
loglog(lambdak,AEinfV(:,3),'-.','linewidth',3,'color','black'), box on, 
set(gca, 'FontSize', 35, 'XMinorGrid', 'on'), set(gca, 'FontSize', 35, 'YMinorGrid', 'on'),
loglog(lambdak(xmin_lh),min(AE2V(:,3)),'pentagram','linewidth',2,'MarkerSize',30,'color','red','MarkerFaceColor','red'), hold on,
loglog(lambdak(xmin_lh_infity),min(AEinfV(:,3)),'diamond','linewidth',2,'MarkerSize',30,'color','red','MarkerFaceColor','red'), hold on,


title({'\textbf{Lasso hyperinterpolation}'},'interpreter','latex','fontsize',35);
xlabel({'\textbf{Regularization parameter} $\lambda$'},'interpreter','latex','fontsize',35);
legend({'$L_2$ \textbf{norm of error}','$L_{\infty}$ \textbf{norm of error}',['{\textbf{Minimum at}} $\lambda=$',num2str(lambdak(xmin_lh))],['{\textbf{Minimum at}} $\lambda=$',num2str(lambdak(xmin_lh_infity))]},'interpreter','latex','fontsize',40,'Location','northwest');


% hybrid hyper.
figure(3)

[xmin_hh, ] = find(AE2V(:,4) == min(AE2V(:,4)));
[xmin_hh_infity, ] = find(AEinfV(:,4) == min(AEinfV(:,4)));

loglog(lambdak,AE2V(:,4),'linewidth',3,'color','blue'), box on, 
set(gca, 'FontSize', 35, 'XMinorGrid', 'on'), set(gca, 'FontSize', 35, 'YMinorGrid', 'on'),
hold on,
loglog(lambdak,AEinfV(:,4),'-.','linewidth',3,'color','black'), box on, 
set(gca, 'FontSize', 35, 'XMinorGrid', 'on'), set(gca, 'FontSize', 35, 'YMinorGrid', 'on'),
loglog(lambdak(xmin_hh),min(AE2V(:,4)),'pentagram','linewidth',2,'MarkerSize',30,'color','red','MarkerFaceColor','red'), hold on,
loglog(lambdak(xmin_hh_infity),min(AEinfV(:,4)),'diamond','linewidth',2,'MarkerSize',30,'color','red','MarkerFaceColor','red'), hold on,


title({'\textbf{Hybrid hyperinterpolation}'},'interpreter','latex','fontsize',35);
xlabel({'\textbf{Regularization parameter} $\lambda$'},'interpreter','latex','fontsize',35);
legend({'$L_2$ \textbf{norm of error}','$L_{\infty}$ \textbf{norm of error}',['{\textbf{Minimum at}} $\lambda=$',num2str(lambdak(xmin_hh))],['{\textbf{Minimum at}} $\lambda=$',num2str(lambdak(xmin_hh_infity))]},'interpreter','latex','fontsize',40,'Location','northwest');

idx_all = [min(xmin_hth),xmin_lh,xmin_hh];
idx_infity = [min(xmin_hth_infity),xmin_lh_infity,xmin_hh_infity];

sparsity_all = [beta0V(min(xmin_hth),1),beta0V(1,2),beta0V(xmin_lh,3),beta0V(xmin_hh,4),beta0V(min(xmin_hth),5),beta0V(1,6)];

sparsity_infity = [beta0V(min(xmin_hth_infity),1),beta0V(1,2),beta0V(xmin_lh_infity,3),beta0V(xmin_hh_infity,4),beta0V(min(xmin_hth_infity),5),beta0V(1,6)];


lambdaL = lambdak;

fprintf("....Variants.....lambda.....smallest $L_2$ error.....sparsity.....lambda.....smallest maximum error.....sparsity.....\n")
fprintf("{\\em{Hyperint.}} & $ - $ & $ %.6f $ & $ %d $ & $ - $ & $%.6f$ & $%d$ \n",AE2V(6,6),sparsity_all(6),AEinfV(6,6),sparsity_infity(6))
fprintf("\n")
fprintf("{\\em{Filtered}} & $ - $ & $ %.6f $ & $ %d $ & $ - $ & $%.6f$ & $%d$ \n", AE2V(2,2),sparsity_all(2),AEinfV(2,2),sparsity_infity(2))
fprintf("\n")
fprintf("{\\em{Lasso}} & $ %.6f $ & $ %.6f $ & $ %d $ & $ %.6f $ & $%.6f$ & $%d$ \n",lambdaL(idx_all(2)),AE2V(idx_all(2),3),sparsity_all(3),lambdaL(idx_infity(2)),AEinfV(idx_infity(2),3),sparsity_infity(3))
fprintf("\n")
fprintf("{\\em{Hybrid}} & $ %.6f $ & $ %.6f $ & $ %d $ & $ %.6f $ & $%.6f$ & $%d$ \n",lambdaL(idx_all(3)),AE2V(idx_all(3),4),sparsity_all(4),lambdaL(idx_infity(3)),AEinfV(idx_infity(3),4),sparsity_infity(4))
fprintf("\n")
fprintf("{\\em{Hard}} & $ %.6f $ & $ %.6f $ & $ %d $ & $ %.6f $ & $%.6f$ & $%d$ \n",lambdaL(idx_all(1)),AE2V(idx_all(1),5),sparsity_all(5),lambdaL(idx_infity(1)),AEinfV(idx_infity(1),5),sparsity_infity(5))
fprintf("\n")

end

%% Functions used in this programm

function XYW=cub_disk_productrule(N)

% PRODUCT TYPE RULE ON THE UNIT DISK: ade at least "N". 

n=ceil(N/2);
gaussian_type=1;

switch gaussian_type
    case 1
        % Gaussian rule in [0,1]: ade=2*n -> n+1 points.
        ab=r_jacobi(n+1,0,0); xw=gauss(n+1,ab);
        r0=xw(:,1); wr0=xw(:,2); r=(r0+1)/2; wr=wr0/2;
        %     case 2
        %         xw=lobatto_jacobi(n,0,0); % ADE: 2*n+1 using n+2 points.
        %         r0=xw(:,1); wr0=xw(:,2); r=(r0+1)/2; wr=wr0/2;
        %     case 3
        %         xw=radau_jacobi(n,1,0,0); % ADE: 2*n using n+1 points.
        %         r0=xw(:,1); wr0=xw(:,2); r=(r0+1)/2; wr=wr0/2;
end

% Trapezoidal rule.
m=0:2*n; th=2*pi*m/(2*n+1); th=th';
wth=2*pi*ones(size(th))/(2*n+1);

% Nodes in polar coordinates.
[R,TH]=meshgrid(r,th);
Rv=R(:); THv=TH(:);
X=Rv.*cos(THv); Y=Rv.*sin(THv);

[W1,W2]=meshgrid(wr.*r,wth);
W=W1.*W2; W=W(:);

XYW=[X Y W];

end





function plot_error_disk(f,coeff,n)

t=-1:0.01:1;
[XR,YR]=meshgrid(t);

fXYR=feval(f,XR,YR);
VR=vandermonde_logan_shepp(n,[XR(:) YR(:)]);
pXYR0=VR*coeff;

pXYR=reshape(pXYR0,size(XR,1),size(XR,2));

val=(ones(size(XR))-XR.^2-YR.^2) >= 0;
err=abs(fXYR-pXYR).*val;

plot3(XR,YR,err);
hold on;
AZ=20; EL=45;
view(AZ,EL);
hold off;

end





function g=define_function(funct_example,L)

% function to test

switch funct_example

    case 1 % test exactness hyperinterpolation
        nexp=L;
        c0=rand(1); c1=rand(1); c2=rand(1);
        g=@(x,y) (c0+c1*x+c2*y).^nexp;

    case 2 % test exactness filt. hyperinterpolation
        nexp=max(floor(L/2)-1,0);
        c0=rand(1); c1=rand(1); c2=rand(1);
        g=@(x,y) (c0+c1*x+c2*y).^nexp;

    case 3 % function of that type

        %  Test function.

        funct_example_sub=1;

        switch funct_example_sub
            case 1
                g=@(x,y) (1-x.^2-y.^2).*exp(x.*cos(y));
                fstring='(1-x.^2-y.^2).*exp(x.*cos(y))';
            case 2
                g=@(x,y) exp((x.^6).*cos(y));
                fstring='exp((x.^6).*cos(y))';
        end
end

end

function [pXYR_re, abs_err] = evaluate_disk(f,coeff,n)

t = -1:0.025:1;
[XR, YR] = meshgrid(t);

fXYR = feval(f, XR, YR);
VR = vandermonde_logan_shepp(n, [XR(:) YR(:)]);

pXYR0 = VR*coeff;

pXYR = reshape(pXYR0,size(XR,1),size(XR,2));

val = (ones(size(XR))- XR.^2 - YR.^2) >=0;

val = val./val;

abs_err = abs(fXYR-pXYR).*val;
pXYR_re = pXYR.*val;
end

%function [noisy_function,real_function ]= noise_fun(f,a)
function [noisy_function,real_function ]= noise_fun(f,sigma,a)
t = -1:0.025:1;
[XR, YR] = meshgrid(t);

fXYR = feval(f, XR, YR);

val = (ones(size(XR))- XR.^2 - YR.^2) >=0;

val = val./val;

%noisy_function = (fXYR + a*(1-2*rand(length(fXYR),1))*binornd(1,0.5) ).*val;
noisy_function = (fXYR + sigma*randn(size(fXYR)) + a*(1-2*rand(length(fXYR),1))*binornd(1,0.5)).*val;
real_function = fXYR.*val;
end