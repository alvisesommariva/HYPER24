function [pert,coeff0,idx_infity,var]=demo_cube_plot_error
% Codes based on Alvise Sommariva (University of Padova)
% Date: 18 August, 2023
% demo_cube_plot is used to plot original function
% and its recovery function via different hyperinterpolants
% in the cube

LV=20;      % Hyperinterpolant tot degree.
NV=2*LV;    % Degree of the rule.
NR=50;      % Reference rule for computing L2 errors.

% * Function to approximate:
% 1. degree L poly., 2. degree floor(L/2)-1 poly. 3. test functions
% (see line 274 approx).
funct_example=3;

% The degree d of the polynomial space is d = (LV+3)(LV+2)(LV+1)/6.
% The quadrature points N = (NV+2)^3/4.



% ........ Numerical approximation, varying the degree in "nV" ............

AEinfMV=[]; AE2MV=[]; beta0MV=[]; % vectors used for statistics

% Define quadrature rule for hyperinterpolation at degree N.
XYZW=cub_cube(NV); X=XYZW(:,1); Y=XYZW(:,2); Z=XYZW(:,3); W=XYZW(:,4);

% Test points
XYZWR=cub_cube(NR); XR=XYZWR(:,1); YR=XYZWR(:,2); ZR=XYZWR(:,3); WR=XYZWR(:,4);

% Vandermonde matrix at nodes and polynomial degrees.
[V,dbox,duples]=dCHEBVAND0(LV,[X Y Z]);
degs=sum(duples,2);

% define function (see attached file at the bottom)
g=choose_function(funct_example,LV);

% ... evaluate function to approximate ...
gXYZ=feval(g,X,Y,Z);


sigma = 0.2; var=sigma^2; pert=sqrt(var)*randn(size(gXYZ));

% add Gaussian noise

gXYZ_pert=gXYZ+pert;

% ... determine polynomial hyperinterpolant ...
coeff0=(gXYZ_pert.*W)'*V; coeff0=coeff0';

% we reference to the method in "RBF approximation of noisy scattered data on the sphere"
lambdas = -15:0.1:7;

lambdak=2.^lambdas;

for k = 1:length(lambdas)
lambdaL = lambdak(k);

for ktest=1:6
            switch ktest
                case 1
                    hypermode='tikhonov';
                    parms.lambda=lambdaL;
                    parms.mu=[];
                    parms.b=ones(size(coeff0));
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 2
                    hypermode='filtered';
                    parms.lambda=[];
                    parms.mu=[];
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 3
                    hypermode='lasso';
                    parms.lambda=lambdaL;
                    parms.mu=ones(size(coeff));
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 4
                    hypermode='hybrid';
                    parms.lambda=lambdaL;
                    parms.mu=ones(size(coeff0));
                    parms.b=ones(size(coeff0));
                    parms.w=W;
                    parms.pert=pert;
                    parms.hybrid=0; % establishes it is a pre-choosen parameter.
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 5
                    hypermode='hard';
                    parms.lambda=lambdaL;
                    parms.mu=[];
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 6
                    hypermode='hyperinterpolation';
                    parms.lambda=[];
                    parms.mu=[];
                    parms.b=[];
                    coeff=coeff0;
            end

            gXYZR=feval(g,XR,YR,ZR);
            [VR]=dCHEBVAND0(LV,[XR YR ZR]);
            pXYZR(:,ktest)=VR*coeff;

            % errors
            AEinfV(k,ktest)=norm(gXYZR-pXYZR(:,ktest),inf); % absolute error (inf norm)
            AE2V(k,ktest)=sqrt(WR'*((gXYZR-pXYZR(:,ktest)).^2)); % absolute error (2 norm)
            beta0V(k,ktest)=sum(abs(coeff) > 0);

end

end


% hard thresholding hyper.
figure(1)
[xmin_hth, ] = find(AE2V(:,5) == min(AE2V(:,5)));
[xmin_hth_infity, ] = find(AEinfV(:,5) == min(AEinfV(:,5)));

loglog(lambdak,AE2V(:,5),'linewidth',3,'color','blue'), box on, 
set(gca, 'FontSize', 35, 'XMinorGrid', 'on'), set(gca, 'FontSize', 35, 'YMinorGrid', 'on'),
hold on,
loglog(lambdak,AEinfV(:,5),'-.','linewidth',3,'color','black'), box on, 
set(gca, 'FontSize', 35, 'XMinorGrid', 'on'), set(gca, 'FontSize', 35, 'YMinorGrid', 'on'),
loglog(lambdak(xmin_hth),min(AE2V(:,5)),'pentagram','linewidth',2,'MarkerSize',30,'color','red','MarkerFaceColor','red'), hold on,
loglog(lambdak(xmin_hth_infity),min(AEinfV(:,5)),'diamond','linewidth',2,'MarkerSize',30,'color','red','MarkerFaceColor','red'), hold on,


title({'\textbf{Hard thresholding hyperinterpolation}'},'interpreter','latex','fontsize',35);
xlabel({'\textbf{Regularization parameter} $\lambda$'},'interpreter','latex','fontsize',35);
legend({'$L_2$ \textbf{norm of error}','$L_{\infty}$ \textbf{norm of error}',['{\textbf{Minimum at}} $\lambda \in [$',num2str(min(lambdak(xmin_hth))),'$,\:$', num2str(max(lambdak(xmin_hth))),'$]$'],['{\textbf{Minimum at}} $\lambda \in [$',num2str(min(lambdak(xmin_hth_infity))),'$,\:$', num2str(max(lambdak(xmin_hth_infity))),'$]$']},'interpreter','latex','fontsize',40,'Location','northwest');

% lasso hyper.
figure(2)
[xmin_lh, ] = find(AE2V(:,3) == min(AE2V(:,3)));
[xmin_lh_infity, ] = find(AEinfV(:,3) == min(AEinfV(:,3)));

loglog(lambdak,AE2V(:,3),'linewidth',3,'color','blue'), box on, 
set(gca, 'FontSize', 35, 'XMinorGrid', 'on'), set(gca, 'FontSize', 35, 'YMinorGrid', 'on'),
hold on,
loglog(lambdak,AEinfV(:,3),'-.','linewidth',3,'color','black'), box on, 
set(gca, 'FontSize', 35, 'XMinorGrid', 'on'), set(gca, 'FontSize', 35, 'YMinorGrid', 'on'),
loglog(lambdak(xmin_lh),min(AE2V(:,3)),'pentagram','linewidth',2,'MarkerSize',30,'color','red','MarkerFaceColor','red'), hold on,
loglog(lambdak(xmin_lh_infity),min(AEinfV(:,3)),'diamond','linewidth',2,'MarkerSize',30,'color','red','MarkerFaceColor','red'), hold on,


title({'\textbf{Lasso hyperinterpolation}'},'interpreter','latex','fontsize',35);
xlabel({'\textbf{Regularization parameter} $\lambda$'},'interpreter','latex','fontsize',35);
legend({'$L_2$ \textbf{norm of error}','$L_{\infty}$ \textbf{norm of error}',['{\textbf{Minimum at}} $\lambda=$',num2str(lambdak(xmin_lh))],['{\textbf{Minimum at}} $\lambda=$',num2str(lambdak(xmin_lh_infity))]},'interpreter','latex','fontsize',40,'Location','northwest');


% hybrid hyper.
figure(3)

[xmin_hh, ] = find(AE2V(:,4) == min(AE2V(:,4)));
[xmin_hh_infity, ] = find(AEinfV(:,4) == min(AEinfV(:,4)));

loglog(lambdak,AE2V(:,4),'linewidth',3,'color','blue'), box on, 
set(gca, 'FontSize', 35, 'XMinorGrid', 'on'), set(gca, 'FontSize', 35, 'YMinorGrid', 'on'),
hold on,
loglog(lambdak,AEinfV(:,4),'-.','linewidth',3,'color','black'), box on, 
set(gca, 'FontSize', 35, 'XMinorGrid', 'on'), set(gca, 'FontSize', 35, 'YMinorGrid', 'on'),
loglog(lambdak(xmin_hh),min(AE2V(:,4)),'pentagram','linewidth',2,'MarkerSize',30,'color','red','MarkerFaceColor','red'), hold on,
loglog(lambdak(xmin_hh_infity),min(AEinfV(:,4)),'diamond','linewidth',2,'MarkerSize',30,'color','red','MarkerFaceColor','red'), hold on,


title({'\textbf{Hybrid hyperinterpolation}'},'interpreter','latex','fontsize',35);
xlabel({'\textbf{Regularization parameter} $\lambda$'},'interpreter','latex','fontsize',35);
legend({'$L_2$ \textbf{norm of error}','$L_{\infty}$ \textbf{norm of error}',['{\textbf{Minimum at}} $\lambda=$',num2str(lambdak(xmin_hh))],['{\textbf{Minimum at}} $\lambda=$',num2str(lambdak(xmin_hh_infity))]},'interpreter','latex','fontsize',40,'Location','northwest');

idx_all = [min(xmin_hth),xmin_lh,xmin_hh];
idx_infity = [min(xmin_hth_infity),xmin_lh_infity,xmin_hh_infity];

sparsity_all = [beta0V(min(xmin_hth),1),beta0V(1,2),beta0V(xmin_lh,3),beta0V(xmin_hh,4),beta0V(min(xmin_hth),5),beta0V(1,6)];

sparsity_infity = [beta0V(min(xmin_hth_infity),1),beta0V(1,2),beta0V(xmin_lh_infity,3),beta0V(xmin_hh_infity,4),beta0V(min(xmin_hth_infity),5),beta0V(1,6)];


lambdaL = lambdak;

fprintf("....Variants.....lambda.....smallest $L_2$ error.....sparsity.....lambda.....smallest maximum error.....sparsity.....\n")
fprintf("{\\em{Hyperint.}} & $ - $ & $ %.6f $ & $ %d $ & $ - $ & $%.6f$ & $%d$ \n",AE2V(6,6),sparsity_all(6),AEinfV(6,6),sparsity_infity(6))
fprintf("\n")
fprintf("{\\em{Filtered}} & $ - $ & $ %.6f $ & $ %d $ & $ - $ & $%.6f$ & $%d$ \n", AE2V(2,2),sparsity_all(2),AEinfV(2,2),sparsity_infity(2))
fprintf("\n")
fprintf("{\\em{Lasso}} & $ %.6f $ & $ %.6f $ & $ %d $ & $ %.6f $ & $%.6f$ & $%d$ \n",lambdaL(idx_all(2)),AE2V(idx_all(2),3),sparsity_all(3),lambdaL(idx_infity(2)),AEinfV(idx_infity(2),3),sparsity_infity(3))
fprintf("\n")
fprintf("{\\em{Hybrid}} & $ %.6f $ & $ %.6f $ & $ %d $ & $ %.6f $ & $%.6f$ & $%d$ \n",lambdaL(idx_all(3)),AE2V(idx_all(3),4),sparsity_all(4),lambdaL(idx_infity(3)),AEinfV(idx_infity(3),4),sparsity_infity(4))
fprintf("\n")
fprintf("{\\em{Hard}} & $ %.6f $ & $ %.6f $ & $ %d $ & $ %.6f $ & $%.6f$ & $%d$ \n",lambdaL(idx_all(1)),AE2V(idx_all(1),5),sparsity_all(5),lambdaL(idx_infity(1)),AEinfV(idx_infity(1),5),sparsity_infity(5))
fprintf("\n")


end

%% Function used in this programm

function g=choose_function(funct_example,L)

switch funct_example

    case 1 % test exactness hyperinterpolation
        nexp=L;
        c0=rand(1); c1=rand(1); c2=rand(1); c3=rand(1);
        g=@(x,y,z) (c0+c1*x+c2*y+c3*z).^nexp;

    case 2 % test exactness filt. hyperinterpolation
        nexp=max(floor(L/2)-1,0);
        c0=rand(1); c1=rand(1); c2=rand(1); c3=rand(1);
        g=@(x,y,z) (c0+c1*x+c2*y+c3*z).^nexp;

    case 3 % function of that type

        funct_example_sub=0;

        switch funct_example_sub
            case 0 % Test function used in the accompanying paper.
                g=@(x,y,z) exp(-1./(x.^2+y.^2+z.^2));
                % fstring='exp(-1./(x.^2+y.^2+z.^2))';
            case 1
                g=@(x,y,z) (1-x.^2-y.^2-z.^2).*exp(x.*cos(y));
                % fstring='(1-x.^2-y.^2-z.^2).*exp(x.*cos(y))';
            case 2
                g=@(x,y,z) exp((x.^6).*cos(y+2*z));
                % fstring='exp((x.^6).*cos(y+2*z))';
        end

end        
end

function [pXYZR_3D, abs_err_3D] = evaluate_cube(f,coeff,n)

    TT = -1:0.1:1;
     
    [XR_3, YR_3, ZR_3] = meshgrid(TT);

    fXYZR_3D = feval(f, XR_3, YR_3, ZR_3);

    [V,dbox,duples]=dCHEBVAND0(n,[XR_3(:) YR_3(:) ZR_3(:)]);

    pXYZR0 = V*coeff;

    pXYZR_3D = reshape(pXYZR0,size(XR_3,1),size(YR_3,1),size(ZR_3,1));

    abs_err_3D = abs(fXYZR_3D-pXYZR_3D);
end