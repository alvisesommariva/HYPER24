function demo_uniondisks_plot_new
clear all; clc;

[X,Y,gXY_pert,idx_infity,coeff0,W,pert,degs,R,jvec,centerV,rV,dbox,g,L]=demo_uniondisks_plot_error;

% n_grid: dimension of the grid of test points per direction.
n_grid=300;

% Test points
xmin = dbox(1); xmax = dbox(2); ymin = dbox(1); ymax = dbox(2);

xgrid=linspace(xmin,xmax,n_grid); ygrid=linspace(ymin,ymax,n_grid);
[Mx,My]=meshgrid(xgrid,ygrid);
XR=Mx(:); YR=My(:);
Zin=indomain_uniondisks(XR,YR,centerV,rV);

gXYR=feval(g,Mx,My);

lambdas = -15:0.1:7;

lambdaL=2.^lambdas;

for ktest=1:6

    switch ktest
        case 1
            hypermode='tikhonov';
            hypermode_str='Tikhonov hyp.';
            parms.lambda=lambdaL(idx_infity(1));
            parms.mu=[];
            parms.b=ones(size(coeff0));
            coeff=hyperfilter(hypermode,coeff0,degs,parms);
        case 2
            hypermode='filtered';
            hypermode_str='Filtered hyp.';
            parms.lambda=[];
            parms.mu=[];
            parms.b=[];
            coeff=hyperfilter(hypermode,coeff0,degs,parms);
        case 3
            hypermode='lasso';
            hypermode_str='Lasso hyp.';
            parms.lambda=lambdaL(idx_infity(2));
            parms.mu=ones(size(coeff0));
            parms.b=[];
            coeff=hyperfilter(hypermode,coeff0,degs,parms);
        case 4
            hypermode='hybrid';
            hypermode_str='Hybrid hyp.';
            parms.lambda=lambdaL(idx_infity(3));
            parms.mu=ones(size(coeff0));
            parms.b=ones(size(coeff0));
            parms.w=W;
            parms.pert=pert;
            parms.hybrid=0; % establishes it is a pre-choosen parameter.
            coeff=hyperfilter(hypermode,coeff0,degs,parms);
        case 5
            hypermode='hard';
            hypermode_str='Hard thresh. hyp.';
            parms.lambda=lambdaL(idx_infity(1));
            parms.mu=[];
            parms.b=[];
            coeff=hyperfilter(hypermode,coeff0,degs,parms);
        case 6
            hypermode='hyperinterpolation';
            hypermode_str='Classical hyp.';
            parms.lambda=[];
            parms.mu=[];
            parms.b=[];
            coeff=coeff0;
    end

    % evaluate polynomial at reference points
    VR=chebvand(L,[XR YR],dbox);
    pXYR(:,ktest) = (VR(:,jvec)/R)*coeff;


    % errors
%     AEinfV(ktest)=norm(gXYR-pXYR(:,ktest),inf); % absolute error (inf norm)
%     AE2V(ktest)=sqrt(WR'*((gXYR-pXYR(:,ktest)).^2)); % absolute error (2 norm)
%     beta0V(ktest)=sum(abs(coeff) > 0);

    % a) If Zin=0, Zin./Zin=NaN: points outside the domain assume function
    %    value Z1 equal to NaN-1, i.e. NaN.
    % b) If Zin=1, Zin./Zin=1: points inside the domain assume function
    %    value equal to 0.

    Z1=Zin./Zin-1;
    ZV=pXYR(:,ktest)+Z1;


    % approximate resultes
    Mz(:,1+(ktest-1)*300:ktest*300)=reshape(ZV,n_grid,n_grid);
    
    % absolute error
    Mz_err0(:,1+(ktest-1)*300:ktest*300)=abs(gXYR-Mz(:,1+(ktest-1)*300:ktest*300));

end


%% Plot

figure(4)
% 1. Plotting figure
fontsize_baselinea = 20;
fontsize_baseline = 30;
fontsize_baselinet = 35;

% Original funtion 

Mzf=gXYR+reshape(Z1,n_grid,n_grid);

axes('position',[0.075 0.55 0.2 0.4]),
mesh(Mx,My,Mzf); set(gca, 'fontsize', fontsize_baselinea),box on,...
     xlabel('$x$','interpreter','latex', 'fontsize', fontsize_baseline),ylabel('$y$','interpreter','latex', 'fontsize', fontsize_baseline),...%ylabel('$f(x)$','interpreter','latex', 'fontsize', fontsize_baseline),...
     title('\textbf{Original function} $f$','interpreter','latex', 'fontsize', fontsize_baselinet),...
     grid on,...
%      set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'),
axis([-1 1 -1 1 -0.2 1.4]);

% Original function with noise
ZN = gXY_pert;
MzN = griddata(X,Y,ZN,Mx,My,'cubic');
MzN=MzN+reshape(Z1,n_grid,n_grid);

axes('position',[0.075 0.05 0.2 0.4]), 
mesh(Mx,My,MzN);
set(gca, 'fontsize', fontsize_baselinea),xlabel('$x$','interpreter','latex', 'fontsize', fontsize_baseline),ylabel('$y$','interpreter','latex', 'fontsize', fontsize_baseline),...%ylabel('Absolute error','interpreter','latex', 'fontsize', fontsize_baseline),...
    title('\textbf{Noisy function} $f^{\epsilon}$','interpreter','latex', 'fontsize', fontsize_baselinet),box on,  grid on,...
     set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'), axis([-1 1 -1 1 -0.4 1.25]);


% Hyperinterpolation
axes('position',[0.3 0.55 0.2 0.4]),
mesh(Mx,My,Mz(:,1501:1800)); set(gca, 'fontsize', fontsize_baselinea),box on,...
     xlabel('$x$','interpreter','latex', 'fontsize', fontsize_baseline),ylabel('$y$','interpreter','latex', 'fontsize', fontsize_baseline),...%ylabel('$f(x)$','interpreter','latex', 'fontsize', fontsize_baseline),...
     title('$\mathcal{L}_L f^{\epsilon}$','interpreter','latex', 'fontsize', fontsize_baselinet),...
     grid on,...
%      set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'),
axis([-1 1 -1 1 -0.2 1.4]);



axes('position',[0.3 0.05 0.2 0.4]), 
mesh(Mx,My,Mz_err0(:,1501:1800));
set(gca, 'fontsize', fontsize_baselinea),xlabel('$x$','interpreter','latex', 'fontsize', fontsize_baseline),ylabel('$y$','interpreter','latex', 'fontsize', fontsize_baseline),...%ylabel('Absolute error','interpreter','latex', 'fontsize', fontsize_baseline),...
    title('\textbf{Absolute error}','interpreter','latex', 'fontsize', fontsize_baselinet),box on,  grid on,...
     set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'), axis([-1 1 -1 1 0 0.2]);


% Filtered hyper

axes('position',[0.525 0.55 0.2 0.4]),
mesh(Mx,My,Mz(:,301:600)); set(gca, 'fontsize', fontsize_baselinea),box on,...
     xlabel('$x$','interpreter','latex', 'fontsize', fontsize_baseline),ylabel('$y$','interpreter','latex', 'fontsize', fontsize_baseline),...%ylabel('$f(x)$','interpreter','latex', 'fontsize', fontsize_baseline),...
     %title('\textbf{Hard hyper.}','interpreter','latex', 'fontsize', fontsize_baselinet),...
     title('$\mathcal{F}_{L,N} f^{\epsilon}$', 'interpreter','latex','fontsize', fontsize_baselinet),  
     grid on,...
%      set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'),
axis([-1 1 -1 1 -0.2 1.4]);

axes('position',[0.525 0.05 0.2 0.4]), 
mesh(Mx,My,Mz_err0(:,301:600));
set(gca, 'fontsize', fontsize_baselinea),xlabel('$x$','interpreter','latex', 'fontsize', fontsize_baseline),ylabel('$y$','interpreter','latex', 'fontsize', fontsize_baseline),...%ylabel('Absolute error','interpreter','latex', 'fontsize', fontsize_baseline),...
    title('\textbf{Absolute error}','interpreter','latex', 'fontsize', fontsize_baselinet),box on,  grid on,...
     set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'), axis([-1 1 -1 1 0 0.15]);

% Hybrid hyper

axes('position',[0.75 0.55 0.2 0.4]),
mesh(Mx,My,Mz(:,901:1200)); set(gca, 'fontsize', fontsize_baselinea),box on,...
     xlabel('$x$','interpreter','latex', 'fontsize', fontsize_baseline),ylabel('$y$','interpreter','latex', 'fontsize', fontsize_baseline),...%ylabel('$f(x)$','interpreter','latex', 'fontsize', fontsize_baseline),...
     %title('\textbf{Hybrid hyper.}','interpreter','latex', 'fontsize', fontsize_baselinet),...
title(['$\mathcal{H}_L^{\lambda} f^{\epsilon}$ \textbf{with} $\lambda=$',num2str(lambdaL(idx_infity(3)))], 'interpreter','latex','fontsize', fontsize_baselinet),
     grid on,...
%      set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'),
axis([-1 1 -1 1 -0.2 1.4]);

axes('position',[0.75 0.05 0.2 0.4]), 
mesh(Mx,My,Mz_err0(:,901:1200));
set(gca, 'fontsize', fontsize_baselinea),xlabel('$x$','interpreter','latex', 'fontsize', fontsize_baseline),ylabel('$y$','interpreter','latex', 'fontsize', fontsize_baseline),...%ylabel('Absolute error','interpreter','latex', 'fontsize', fontsize_baseline),...
    title('\textbf{Absolute error}','interpreter','latex', 'fontsize', fontsize_baselinet),box on,  grid on,...
     set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'), axis([-1 1 -1 1 0 0.15]);



end

function in=indomain_uniondisks(XV,YV,cents,rs)

%--------------------------------------------------------------------------
% Object:
% Indomain function over union of disks.
%--------------------------------------------------------------------------
% Input:
% XV, YV : vectors of dimension n x 2, points to test
% cents: matrix of dimension d x 2; "cents(k,:)" is the center of the k-th
%        disk;
% r    : vector of dimension d x 1; "r(k)" is the radius of the k-th disk.
%--------------------------------------------------------------------------
% Output:
% in: vector of dimension n x 1, in which "in(k)=1" if "(XV(k), YV(k))" is
%     inside the domain, and "in(k)=0" otherwise.
%--------------------------------------------------------------------------
% Reference:
% "Hybrid hyperinterpolation over general regions"
% Congpei An · Alvise Sommariva · Jia-Shu Ran
%--------------------------------------------------------------------------

Ndisks=length(rs);

for k=1:Ndisks
    C=cents(k,:); r=rs(k);
    Min(:,k)= ( (XV-C(1)).^2+(YV-C(2)).^2 <= r^2 );
end

in= ( sum(Min,2) > 0 );

end