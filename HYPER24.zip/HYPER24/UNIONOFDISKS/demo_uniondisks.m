
function [AEinfMV,AE2MV,beta0MV,lambdaV,XYW,XYWR,JzMV,HzMV,Wg_norm2]=...
    demo_uniondisks(lambda_index,a,sigma,XYW,XYWR)

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Numerical experiment in "Hybrid hyperinterpolation over general regions".
% Region: union of disks.
%--------------------------------------------------------------------------
% Note: inputs are not necessary (just used in multiple experiments by an 
% external driver).
%--------------------------------------------------------------------------
% Usage:
% >> demo_uniondisks
%--------------------------------------------------------------------------
% Note:
% The routine uses 'binornd' that requires Statistics and Machine Learning
% Toolbox.
%--------------------------------------------------------------------------
% Dates:
% Written on January 1, 2023: A. Sommariva.
% Modified on April 22, 2023: A. Sommariva.
%--------------------------------------------------------------------------
% COPYRIGHT
%--------------------------------------------------------------------------
% Copyright (C) 2023- 
%
% Authors:
% Alvise Sommariva
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <https://www.gnu.org/licenses/>.
%--------------------------------------------------------------------------


%--------------------------------------------------------------------------
% Degrees of precision in numerical experiments: can be a vector.
%--------------------------------------------------------------------------
LV=15;     % Hyperinterpolant tot degree.
NV=2*LV;   % Degree of the rule used in hyperinterpolation.
NR=40;     % Degree of precision of the reference rule (estimate L2 error).


%--------------------------------------------------------------------------
% Noise and choice of lasso, hybrid, hard threshold parameter.
%--------------------------------------------------------------------------

noise=1;

if noise
    if nargin <2,a=0.02;end     % defining impulse noise (in experiment 2)
    if nargin <3,sigma=0.02;end % defining gaussian noise (in experiment 2)
else
    a=0; sigma=0; % no noise.
end



% * Function to approximate:
% 1. degree L poly., 2. degree floor(L/2)-1 poly. 3. test functions
% (see line 265 approx).
funct_example=3;

% No table or stats.
display_stats=0;

%--------------------------------------------------------------------------
% Special settings.
%--------------------------------------------------------------------------

% Plot domain and nodes: do_plot=1 (yes), do_plot=0 (no).
do_plot=0;

% Number of tests for reconstructing functions of a type on this domain.
ntests=100;





% ........................ Main code below ................................


% ......................... Define domain .................................

[centerV,rV]=example_disks(2);


% ........ Numerical approximation, varying the degree in "nV" ............

AEinfMV=[]; AE2MV=[]; beta0MV=[]; % vectors used for statistics
JzMV=[]; HzMV=[];

for k=1:length(NV)
    N=NV(k); % Quadrature points (ADE).
    L=LV(k); % Hyperinterpolant degree.

    % Define quadrature rule for hyperinterpolation at L, with  ADE=N.
    if nargin < 4, [~,XYW]=cub_uniondisks(centerV,rV,N,1); end
    if isempty(XYW), [~,XYW]=cub_uniondisks(centerV,rV,N,1); end
    X=XYW(:,1); Y=XYW(:,2); W=XYW(:,3);

    % Test points
    if nargin < 5, [~,XYWR]=cub_uniondisks(centerV,rV,NR,1); end
    if isempty(XYWR), [~,XYWR]=cub_uniondisks(centerV,rV,NR,1); end
    XR=XYWR(:,1); YR=XYWR(:,2); WR=XYWR(:,3);

    % Compute bounding box
    xmin=min(centerV(:,1)-rV); xmax=max(centerV(:,1)+rV);
    ymin=min(centerV(:,2)-rV); ymax=max(centerV(:,2)+rV);
    dbox=[xmin xmax ymin ymax];

    % Compute orthonormal basis matrix at nodes.
    jvec=1:(L+1)*(L+2)/2;
    [U,jvec,Q,R,~,degs] = dORTHVAND(L,[X Y],W,jvec,[],dbox);

    % .. testing AE_L2err hyperinterpolation error for each "f" at "deg" ..
    poly_coeffs=[];
    lambdaV=[];

    % ... define function to approximate ...
    g=define_function(funct_example,L);

    % ... evaluate function to approximate ...
    gXY=feval(g,X,Y);
    gXYR=feval(g,XR,YR);

    for j=1:ntests

        % ... add noise (if present) ...

        % a) add impulse noise
        pert_impulse=0;
        if a > 0
            pert_impulse=a*(1-2*rand(length(gXY),1))*binornd(1,0.5);
            while norm(pert_impulse) == 0
                pert_impulse=a*(1-2*rand(length(gXY),1))*binornd(1,0.5);
            end
        end

        % b) add gaussian noise
        pert_gauss=0;
        if sigma > 0
            var=sigma^2;
            pert_gauss=sqrt(var)*randn(size(gXY));
            while norm(pert_gauss) == 0
                pert_gauss=sqrt(var)*randn(size(gXY));
            end
        end

        % add gaussian + impulse noise
        pert=pert_impulse+pert_gauss;

        % perturbed values
        gXY_pert=gXY+pert;

        % ... determine polynomial hyperinterpolant ...
        % compute hyperinterpolant coefficients
        coeff0=Q'*(sqrt(W).*gXY_pert);

        % ... test hyperinterpolant with or withour filters ...

        lambdas=sort(abs(coeff0),'descend');
        lambdaL=lambdas(lambda_index);

        for ktest=1:6
            switch ktest
                case 1
                    hypermode='tikhonov';
                    parms.lambda=lambdaL;
                    parms.mu=[];
                    parms.b=ones(size(coeff0));
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 2
                    hypermode='filtered';
                    parms.lambda=[];
                    parms.mu=[];
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 3
                    hypermode='lasso';
                    parms.lambda=lambdaL;
                    parms.mu=ones(size(coeff));
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 4
                    hypermode='hybrid';
                    parms.lambda=lambdaL;
                    parms.mu=ones(size(coeff0));
                    parms.b=ones(size(coeff0));
                    parms.w=W;
                    parms.pert=pert;
                    parms.hybrid=0; % establishes it is a pre-choosen parameter.
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 5
                    hypermode='hard';
                    parms.lambda=lambdaL;
                    parms.mu=[];
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 6
                    hypermode='hyperinterpolation';
                    parms.lambda=[];
                    parms.mu=[];
                    parms.b=[];
                    coeff=coeff0;
            end

            % evaluate polynomial at reference points.
            VR=chebvand(L,[XR YR],dbox);
            pXYR = (VR(:,jvec)/R)*coeff;

            % errors
            AEinfV(ktest,j)=norm(gXYR-pXYR,inf); % absolute error (inf norm)
            AE2V(ktest,j)=sqrt(WR'*((gXYR-pXYR).^2)); % absolute error (2 norm)
            beta0V(ktest,j)=sum(abs(coeff) > 0);

            % errors
            AEinfV(ktest,j)=norm(gXYR-pXYR,inf); % absolute error (inf norm)
            AE2V(ktest,j)=sqrt(WR'*((gXYR-pXYR).^2)); % absolute error (2 norm)
            beta0V(ktest,j)=sum(abs(coeff) > 0);

            JzV(ktest,j)=evaluate_J(coeff,coeff0);
            HzV(ktest,j)=evaluate_H(coeff,W,pert,U);

        end

        lambdaV=[lambdaV lambdas];

    end

    % averages of the errors (vectors 5 x 1)

    aver_type=1;

    switch aver_type
        case 0
            AEinfM=mean(AEinfV,2); AE2M=mean(AE2V,2); beta0M=mean(beta0V,2);
            JzM=mean(JzV,2); HzM=mean(HzV,2);
        case 1
            AEinfM=median(AEinfV,2); AE2M=median(AE2V,2); beta0M=median(beta0V,2);
            JzM=median(JzV,2); HzM=median(HzV,2);
    end

    if display_stats
        fprintf('\n       ........ table at degree: %2.0f ........ \n \n ',N);
        HypType=categorical({'tikhonov'; 'filtered'; 'lasso'; 'hybrid'; ...
            'hard'; 'hyperint.'});
        T = table(HypType,AEinfM,AE2M,beta0M,JzM,HzM); disp(T)
    end

    AEinfMV=[AEinfMV AEinfM]; AE2MV=[AE2MV AE2M]; beta0MV=[beta0MV beta0M];
    JzMV=[JzMV JzM]; HzMV=[HzMV HzM];

end

Wg_norm2=(norm(sqrt(W).*gXY,2))^2;




function [cents,rs]=example_disks(example)

if nargin < 1
    example=0;
end

switch example

    case 1
        disks=[
            4.172670690843695e-01 6.443181301936917e-01 9.630885392869130e-01
            4.965443032574213e-02 3.786093826602684e-01 5.468057187389680e-01
            9.027161099152811e-01 8.115804582824772e-01 5.211358308040015e-01
            9.447871897216460e-01 5.328255887994549e-01 2.315943867085238e-01
            4.908640924680799e-01 3.507271035768833e-01 4.888977439201669e-01
            4.892526384000189e-01 9.390015619998868e-01 6.240600881736895e-01
            3.377194098213772e-01 8.759428114929838e-01 6.791355408657477e-01
            9.000538464176620e-01 5.501563428984222e-01 3.955152156685930e-01
            3.692467811202150e-01 6.224750860012275e-01 3.674366485444766e-01
            1.112027552937874e-01 5.870447045314168e-01 9.879820031616328e-01
            7.802520683211379e-01 2.077422927330285e-01 3.773886623955214e-02
            3.897388369612534e-01 3.012463302794907e-01 8.851680082024753e-01
            2.416912859138327e-01 4.709233485175907e-01 9.132868276392390e-01
            4.039121455881147e-01 2.304881602115585e-01 7.961838735852120e-01
            9.645452516838859e-02 8.443087926953891e-01 9.871227865557430e-02
            1.319732926063351e-01 1.947642895670493e-01 2.618711838707161e-01
            9.420505907754851e-01 2.259217809723988e-01 3.353568399627965e-01
            9.561345402298023e-01 1.707080471478586e-01 6.797279513773380e-01
            5.752085950784656e-01 2.276642978165535e-01 1.365531373553697e-01
            5.977954294715582e-02 4.356986841038991e-01 7.212274985817402e-01
            2.347799133724063e-01 3.111022866504128e-01 1.067618616072414e-01
            3.531585712220711e-01 9.233796421032439e-01 6.537573486685596e-01
            8.211940401979591e-01 4.302073913295840e-01 4.941739366392701e-01
            1.540343765155505e-02 1.848163201241361e-01 7.790517232312751e-01
            4.302380165780784e-02 9.048809686798929e-01 7.150370784006941e-01
            1.689900294627044e-01 9.797483783560852e-01 9.037205605563163e-01
            6.491154749564521e-01 4.388699731261032e-01 8.909225043307892e-01
            7.317223856586703e-01 1.111192234405988e-01 3.341630527374962e-01
            6.477459631363067e-01 2.580646959120669e-01 6.987458323347945e-01
            4.509237064309449e-01 4.087198461125521e-01 1.978098266859292e-01
            5.470088922863450e-01 5.948960740086143e-01 3.054094630463666e-02
            2.963208056077732e-01 2.622117477808454e-01 7.440742603674624e-01
            7.446928070741562e-01 6.028430893820830e-01 5.000224355902009e-01
            1.889550150325445e-01 7.112157804336829e-01 4.799221411460605e-01
            6.867754333653150e-01 2.217467340172401e-01 9.047222380673627e-01
            1.835111557372697e-01 1.174176508558059e-01 6.098666484225584e-01
            3.684845964903365e-01 2.966758732183269e-01 6.176663895884547e-01
            6.256185607296904e-01 3.187783019258823e-01 8.594423056462123e-01
            7.802274351513768e-01 4.241667597138072e-01 8.054894245296856e-01
            8.112576886578526e-02 5.078582846611182e-01 5.767215156146851e-01
            9.293859709687300e-01 8.551579709004398e-02 1.829224694149140e-01
            7.757126786084023e-01 2.624822346983327e-01 2.399320105687174e-01
            4.867916324031724e-01 8.010146227697388e-01 8.865119330761013e-01
            4.358585885809191e-01 2.922027756214629e-02 2.867415246410610e-02
            4.467837494298063e-01 9.288541394780446e-01 4.899013885122239e-01
            3.063494720165574e-01 7.303308628554529e-01 1.679271456822568e-01
            5.085086553811270e-01 4.886089738035791e-01 9.786806496411588e-01
            5.107715641721097e-01 5.785250610234389e-01 7.126944716789141e-01
            8.176277083222621e-01 2.372835797715215e-01 5.004716241548430e-01
            7.948314168834530e-01 4.588488281799311e-01 4.710883745419393e-01
            ];

        Ndisks=15;
        cents=disks(1:Ndisks,1:2);
        rs=disks(1:Ndisks,3);

    case 2

        M=20;
        angles=linspace(0,2*pi,M);
        angles=angles';

        r1=2;
        cents1=r1*[cos(angles) sin(angles)];
        rs1=(r1/4)*ones(size(cents1,1),1);

        r2=4;
        cents2=r2*[cos(angles) sin(angles)];
        rs2=(r2/4)*ones(size(cents2,1),1);

        cents=[cents1; cents2]/5;
        rs=[rs1; rs2]/5;

    case 3

        M=45;

        t=linspace(0,5,M);
        y=2*t;
        x=2.5*cos(2*t);
        cents=[x' y'];
        x=2.5*sin(2*t);
        cents0=[x' y'];
        cents=[cents; cents0];
        rs=0.3*ones(size(cents,1),1);



    otherwise
        M=16;
        cents=rand(M,2);
        rs=rand(M,1);
end









function g=define_function(funct_example,L)

% function to test

switch funct_example

    case 1 % test exactness hyperinterpolation
        nexp=L;
        c0=rand(1); c1=rand(1); c2=rand(1);
        g=@(x,y) (c0+c1*x+c2*y).^nexp;

    case 2 % test exactness filt. hyperinterpolation
        nexp=max(floor(L/2)-1,0);
        c0=rand(1); c1=rand(1); c2=rand(1);
        g=@(x,y) (c0+c1*x+c2*y).^nexp;

    case 3 % function of that type

        funct_example_sub=1;

        switch funct_example_sub
            case 1
                g=@(x,y) (1-x.^2-y.^2).*exp(x.*cos(y));
                fstring='(1-x.^2-y.^2).*exp(x.*cos(y))';
            case 2
                g=@(x,y) exp(-(x.^2+y.^2));
                fstring='exp(-(x.^2+y.^2))';
            case 3
                g=@(x,y) sin(-(x.^2+y.^2));
                fstring='sin(-(x.^2+y.^2))';
            case 4
                g=@(x,y) 1+0*x+0*y;
                fstring='1+0*x+0*y';
        end


end





function Jz=evaluate_J(z,alpha)

%--------------------------------------------------------------------------
% Object:
% Evaluate function J(z)=sum( (z(l))^2-2*z(l)*alpha(l) )
%--------------------------------------------------------------------------
% Input:
% z    : vector of dimension d x 1
% alpha: vector of dimension d x 1
%--------------------------------------------------------------------------
% Output:
% Jz: value of J(z)=sum( (z(l))^2-2*z(l)*alpha(l) )
%--------------------------------------------------------------------------
% Reference:
% Quantity relevant in Thm. 5.1 of the paper
% "Hybrid hyperinterpolation over general regions"
% Congpei An · Alvise Sommariva · Jia-Shu Ran
%--------------------------------------------------------------------------

% Jz=sum(z.^2-2*z.*alpha);
Jz=z'*z -2*z'*alpha;



function Hz=evaluate_H(z,w,err,V)

%--------------------------------------------------------------------------
% Object:
% Evaluate function H(z)=2*sum_l( z(l) * sum_j( w(j)*err(j)*V(l,j) ) )
%--------------------------------------------------------------------------
% Input:
% z    : vector of dimension d x 1
% w    : vector of dimension N x 1
% err  : vector of dimension N x 1
% V    : matrix of dimension d x N
%--------------------------------------------------------------------------
% Output:
% Hz: value of H(z)=2*sum_l( z(l) * sum_j( w(j)*err(j)*V(l,j) ) )
%--------------------------------------------------------------------------
% Reference:
% Quantity relevant in Thm. 5.1 of the paper
% "Hybrid hyperinterpolation over general regions"
% Congpei An · Alvise Sommariva · Jia-Shu Ran
%--------------------------------------------------------------------------

inner_term=V'*(w.*err);
Hz=2*(z'*inner_term);





