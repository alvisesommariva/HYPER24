
function [xyw]=QMC_uniondisks(centers0,rs0,Npts)

if nargin < 3, Npts=10^4; end

% compute dbox
xmin=min(centers0(:,1)-rs0); xmax=max(centers0(:,1)+rs0);
ymin=min(centers0(:,2)-rs0); ymax=max(centers0(:,2)+rs0);

% halton points
H = haltonseq(Npts,2);
H=[xmin+(xmax-xmin)*H(:,1) ymin+(ymax-ymin)*H(:,2)];

% test in domain
Ndisks=length(rs0);
in=zeros(Npts,1);
for k=1:Ndisks
    inL=( (centers0(k,1)-H(:,1)).^2+(centers0(k,2)-H(:,2)).^2 ) <= (rs0(k))^2;
    in=in+inL;
end
iok=find(in > 0);

% QMC rule
Hin=H(iok,:);
Nptsin=length(iok);
win=((xmax-xmin)*(ymax-ymin)*Nptsin/Npts)*ones(Nptsin,1);
xyw=[Hin win];


