function [xyw,xywc,centers,rs,active_arcs,disk_sequence,arcs_sizes,momerr]=...
    cub_uniondisks(centerV,rV,ade,comprex_flag)

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Cubature on the union of disks.
%--------------------------------------------------------------------------
% INPUT
%--------------------------------------------------------------------------
% centerV: centers of the disk (N x 2 matrix, N=# disks).
% rV     : radii of the disks (column vector)
% ade    : algebraic degree of precision
% comprex_flag: 0: no compression, 1: compression.
%--------------------------------------------------------------------------
% OUTPUT
%--------------------------------------------------------------------------
% xyw: cubature rule where x=xyw(:,1), y=xyw(:,2), w=xyw(:,3) are such that
%      (x,y) are the nodes while w are the respective weights;
%      it is an M x 3 matrix.
% xywc: compressed cubature rule where x=xywc(:,1),y=xywc(:,2),w=xywc(:,3)
%      are such that (x,y) are the nodes while w are the respective weights;
%      it is an L x 3 matrix.
% centers,rs: they define the disks that contribute to the definition of
%      the domain via their centers and radii;
% active_arcs, disk_sequence, arcs_sizes: parameters defining the boundary;
% momerr: moment reconstruction error by the compressed rule.
%--------------------------------------------------------------------------
% AUTHORS
%--------------------------------------------------------------------------
% A. Sommariva and M. Vianello
% "CUBATURE RULES WITH POSITIVE WEIGHTS ON UNION OF DISKS".
%--------------------------------------------------------------------------
% DATES
%--------------------------------------------------------------------------
% Last version: October 19, 2022.
%--------------------------------------------------------------------------
% SUBROUTINES
%--------------------------------------------------------------------------
% * determine_uniondisks_boundary (attached)
% * determine_polygons_sides (attached)
% * cub_polygon (external): requires cub_triangle (external)
% * cub_union_circsegment (attached)
% * comprexcub (external): requires lawsonhanson (external) or
%        alternatively LHDM (external), depending on the NNLS used in the
%        cubature compression.
%--------------------------------------------------------------------------
% 1A. Determine the boundary of the domain
[centers,rs,active_arcs,disk_sequence,arcs_sizes]=...
    determine_uniondisks_boundary(centerV,rV);

% 2. Cubature rule over the union circular segments.
xyw_segms=cub_union_circsegments(ade,centers,rs,active_arcs,...
    disk_sequence,arcs_sizes);

% 3A. Determine polygon (in general not simply connected).
[xv,yv,iv]=determine_polygons_sides(centers,rs,active_arcs,...
    disk_sequence,arcs_sizes);

% 3B. Determine rule on the polygon described above.
if size(iv,1) > 0
    [xyw_plg,xvc,yvc,pgon,tri]=cub_polygon(ade,xv,yv,iv);
else
    xyw_plg=[];
end

% 4. Assembly final rule.
xyw=[xyw_segms; xyw_plg];

% 5. Make compression if required.
if (comprex_flag == 1) & (nargout >= 2)
    [pts,w,momerr] = comprexcub(ade,xyw(:,1:2),xyw(:,3),3); xywc=[pts w];
else
    xywc=[];
end


% % Some cardinality estimates
% 
% % estimated cardinality of the rule over circular segments
% exp_card_segms=size(disk_sequence,1)*floor((ade+1)/2)*floor((ade+2)/2);
% 
% % estimated cardinality of the rule over polygons
% cc=size(disk_sequence,1);
% num_polygons=pgon.NumRegions; % number of connected components
% if rem(ade,2) == 0
%     exp_card_polygons=(cc-num_polygons*2)*(ade+2)*(ade+4)/8;
% else
%     exp_card_polygons=(cc-num_polygons*2)*(ade+1)*(ade+3)/8;
% end
% 
% % rule cardinality
% dim_poly=(ade+1)*(ade+2)/2;
% Lbound=(3*cc/4-num_polygons/2)*dim_poly;
% 
% % write results
% fprintf('\n \t * Cardinality circ.segments    : %6.0f [%6.0f]',...
%     size(xyw_segms,1),exp_card_segms);
% fprintf('\n \t * Cardinality polygons         : %6.0f [%6.0f]',...
%     size(xyw_plg,1),exp_card_polygons);
% fprintf('\n \t * Cardinality rule             : %6.0f [%6.0f]',...
%     size(xyw,1),Lbound);



%--------------------------------------------------------------------------
% determine_polygons_sides
%--------------------------------------------------------------------------

function [xv,yv,iv]=determine_polygons_sides(centers,rs,active_arcs,...
    disk_sequence,arcs_sizes)

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% This routine, given the centers, the radii, the sequence of "arcs" (via
% "active_arcs", "disk_sequence", "arcs_sizes"), provides the sides of the
% polygon (possibly including those defining the holes).
%--------------------------------------------------------------------------

M=size(rs,1);

% plotting sequences.
T=active_arcs;

xv=[]; yv=[]; iv=[];

% arc_sequence,disk_sequence,arcs_sizes
for ii=1:length(arcs_sizes)

    init_ii=sum(arcs_sizes(1:ii-1))+1;
    end_ii=sum(arcs_sizes(1:ii));


    xvL=[]; yvL=[];

    for jj=init_ii:end_ii
        CC=centers(disk_sequence(jj),:);
        r=rs(disk_sequence(jj));
        angs=T(jj,:);
        if abs(diff(angs)) > 0
            xvLL=CC(1)+r*cos(angs(2));
            yvLL=CC(2)+r*sin(angs(2));
            xvL=[xvL; xvLL]; yvL=[yvL; yvLL];
        end
    end

    LL=length(xvL);

    if LL >= 3
        xv=[xv; xvL]; yv=[yv; yvL]; iv=[iv; length(xvL)];
    end

end





%--------------------------------------------------------------------------
% cub_circsegment
%--------------------------------------------------------------------------

function xyw=cub_union_circsegments(ade,centers,rs,active_arcs,...
    disk_sequence,arcs_sizes)

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% This routine, given the centers, the radii, the sequence of "arcs" (via
% "active_arcs", "disk_sequence", "arcs_sizes"), provides a rule over with
% algebraic degree of precision "ade", over the union of circular segments
% defined by the algorithm.
% The nodes are "xyw(:,1:2)", the weights are "xyw(:,3)".
%--------------------------------------------------------------------------

M=size(rs,1);

% plotting sequences.
T=active_arcs;

xyw=[];

% arc_sequence,disk_sequence,arcs_sizes
for ii=1:length(arcs_sizes)

    init_ii=sum(arcs_sizes(1:ii-1))+1;
    end_ii=sum(arcs_sizes(1:ii));

    for jj=init_ii:end_ii
        CC=centers(disk_sequence(jj),:);
        r=rs(disk_sequence(jj));
        angs=T(jj,:);
        if abs(diff(angs)) > 0
            xywL=cub_circularsegment(ade,CC,r,angs(1),angs(2));
            % fprintf('\n \t card loc: %5.0f',size(xywL,1));
            xyw=[xyw; xywL];
        end
    end

end

































