function demo_sphere_plot_new

clear all;clc;

[X,Y,Z,gXYZ_pert,gXYZR,XR,YR,ZR,idx_all,idx_infity,coeff0,VR,WR,W,pert,degs]=demo_sphere_plot_error;

lambdas = -15:0.1:7;

lambdaL=2.^lambdas;

for ktest=1:6
            switch ktest
                case 1
                    hypermode='tikhonov';
                    parms.lambda=lambdaL(idx_infity(1));
                    parms.mu=[];
                    parms.b=ones(size(coeff0));
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 2
                    hypermode='filtered';
                    parms.lambda=[];
                    parms.mu=[];
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 3
                    hypermode='lasso';
                    parms.lambda=lambdaL(idx_infity(2));
                    parms.mu=ones(size(coeff));
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 4
                    hypermode='hybrid';
                    parms.lambda=lambdaL(idx_infity(3));
                    parms.mu=ones(size(coeff0));
                    parms.b=ones(size(coeff0));
                    parms.w=W;
                    parms.pert=pert;
                    parms.hybrid=0; % establishes it is a pre-choosen parameter.
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 5
                    hypermode='hard';
                    parms.lambda=lambdaL(idx_infity(1));
                    parms.mu=[];
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 6
                    hypermode='hyperinterpolation';
                    parms.lambda=[];
                    parms.mu=[];
                    parms.b=[];
                    coeff=coeff0;
            end

            %gXYZR=feval(g,XR,YR,ZR);
            %[VR,degs]=vandermonde_sphharm(LV,[XR YR,ZR]);
            pXYZR(:,ktest)=VR*coeff;

            % errors
            AEinfV(ktest)=norm(gXYZR-pXYZR(:,ktest),inf); % absolute error (inf norm)
            AE2V(ktest)=sqrt(WR'*((gXYZR-pXYZR(:,ktest)).^2)); % absolute error (2 norm)
            beta0V(ktest)=sum(abs(coeff) > 0);
end

%% Plot

figure(4)

[Fmax, imax] = max(gXYZR);
[Fmin, imin] = min(gXYZR);
scale = -0.35;
scale1 = -scale;
FS = 1 + (scale/(Fmax-Fmin))*(gXYZR-Fmin);
FS1 = 1 + (scale1/(Fmax-Fmin))*(gXYZR-Fmin);
fontsize_baselinet = 38;
fontsize_baselinea = 20;

tri = convhull([XR YR ZR]);

% exact function and its noisy function
axes('position',[0.025,0.55,0.2,0.47])
fg = trisurf(tri,XR.*FS, YR.*FS, ZR.*FS, gXYZR,'facecolor','interp');
set(fg,'EdgeColor', 'none'),set(gca, 'fontsize', fontsize_baselinea);
title('\textbf{Original function} $f$','interpreter','latex','fontsize',fontsize_baselinet,'position',[0,0,1.25])
colormap(jet(255));
view(-25,25), axis vis3d, axis equal tight, colorbar('south'), %caxis([1.32,1.47])
axis off

tri1 = convhull([X Y Z]);

axes('position',[0.025 0.05 0.2 0.47])
[Fmax, imax] = max(gXYZ_pert);
[Fmin, imin] = min(gXYZ_pert);

FS = 1 + (scale/(Fmax-Fmin))*(gXYZ_pert-Fmin);
fg = trisurf(tri1,X.*FS, Y.*FS, Z.*FS, gXYZ_pert,'facecolor','interp');
set(fg,'EdgeColor', 'none'),set(gca, 'fontsize', fontsize_baselinea);
title('\textbf{Noisy function} $f^{\epsilon}$','interpreter','latex','fontsize',fontsize_baselinet,'position',[0,0,1.35])
colormap(jet(255));
view(-25,25), axis vis3d, axis equal tight, colorbar('south'),%caxis([1.32,1.47]),
axis off

% Hyper. and its error

axes('position',[0.275 0.55 0.2 0.47])
[Fmax, imax] = max(pXYZR(:,6));
[Fmin, imin] = min(pXYZR(:,6));

FS = 1 + (scale/(Fmax-Fmin))*(pXYZR(:,6)-Fmin);
fg = trisurf(tri,XR.*FS, YR.*FS, ZR.*FS, pXYZR(:,6),'facecolor','interp');
set(fg,'EdgeColor', 'none'),set(gca, 'fontsize', fontsize_baselinea);
title('$\mathcal{L}_Lf^{\epsilon}$','interpreter','latex','fontsize',fontsize_baselinet,'position',[0,0,1.25])
colormap(jet(255));
view(-25,25), axis vis3d, axis equal tight, colorbar('south'),clim([min(gXYZR),max(gXYZR)]),
axis off

axes('position',[0.275,0.05,0.2,0.47])
[Fmax, imax] = max(abs(pXYZR(:,6)-gXYZR));
[Fmin, imin] = min(abs(pXYZR(:,6)-gXYZR));

FS1 = 1 + (scale1/(Fmax-Fmin))*(abs(pXYZR(:,6)-gXYZR)-Fmin);
fg = trisurf(tri,XR.*FS1, YR.*FS1, ZR.*FS1, abs(pXYZR(:,6)-gXYZR),'facecolor','interp');
set(fg,'EdgeColor', 'none'),set(gca, 'fontsize', fontsize_baselinea);
title('\textbf{Absolute error}','interpreter','latex','fontsize',fontsize_baselinet,'position',[0,0,1.45])
colormap(jet(255));
view(-25,25), axis vis3d, axis equal tight, colorbar('south'),clim([min(abs(pXYZR(:,2)-gXYZR)),max(abs(pXYZR(:,2)-gXYZR))]),
axis off

% Filtered hyper. and its error
axes('position',[0.525 0.55 0.2 0.47])
[Fmax, imax] = max(pXYZR(:,2));
[Fmin, imin] = min(pXYZR(:,2));

FS = 1 + (scale/(Fmax-Fmin))*(pXYZR(:,2)-Fmin);
fg = trisurf(tri,XR.*FS, YR.*FS, ZR.*FS, pXYZR(:,2),'facecolor','interp');
set(fg,'EdgeColor', 'none'),set(gca, 'fontsize', fontsize_baselinea);
title('$\mathcal{F}_{L,N} f^{\epsilon}$ ', 'interpreter','latex','fontsize', fontsize_baselinet,'position',[0,0,1.25]),
colormap(jet(255));
view(25,25), axis vis3d, axis equal tight, colorbar('south'),clim([min(gXYZR),max(gXYZR)]),
axis off

axes('position',[0.525,0.05,0.2,0.47])
[Fmax, imax] = max(abs(pXYZR(:,2)-gXYZR));
[Fmin, imin] = min(abs(pXYZR(:,2)-gXYZR));

FS1 = 1 + (scale1/(Fmax-Fmin))*(abs(pXYZR(:,2)-gXYZR)-Fmin);
fg = trisurf(tri,XR.*FS1, YR.*FS1, ZR.*FS1, abs(pXYZR(:,2)-gXYZR),'facecolor','interp');
set(fg,'EdgeColor', 'none'),set(gca, 'fontsize', fontsize_baselinea);
title('\textbf{Absolute error}','interpreter','latex','fontsize',fontsize_baselinet,'position',[0,0,1.45])
colormap(jet(255));
view(25,25), axis vis3d, axis equal tight, colorbar('south'),clim([min(abs(pXYZR(:,2)-gXYZR)),max(abs(pXYZR(:,2)-gXYZR))]),
axis off

% hybrid hyper. and its error
axes('position',[0.775 0.55 0.2 0.47])    
[Fmax, imax] = max(pXYZR(:,4));
[Fmin, imin] = min(pXYZR(:,4));

FS = 1 + (scale/(Fmax-Fmin))*(pXYZR(:,4)-Fmin);
fg = trisurf(tri,XR.*FS, YR.*FS, ZR.*FS, pXYZR(:,4),'facecolor','interp');
set(fg,'EdgeColor', 'none'),set(gca, 'fontsize', fontsize_baselinea);
title(['$\mathcal{H}_L^{\lambda} f^{\epsilon}$ \textbf{with} $\lambda=$',num2str(lambdaL(idx_infity(3)))], 'interpreter','latex','fontsize', fontsize_baselinet, 'position',[0,0,1.25])
colormap(jet(255));
view(25,25), axis vis3d, axis equal tight, colorbar('south'),clim([min(gXYZR),max(gXYZR)]),
axis off

axes('position',[0.775,0.05,0.2,0.47])    
[Fmax, imax] = max(abs(pXYZR(:,4)-gXYZR));
[Fmin, imin] = min(abs(pXYZR(:,4)-gXYZR));

FS1 = 1 + (scale1/(Fmax-Fmin))*(abs(pXYZR(:,4)-gXYZR)-Fmin);
fg = trisurf(tri,XR.*FS1, YR.*FS1, ZR.*FS1, abs(pXYZR(:,4)-gXYZR),'facecolor','interp');
set(fg,'EdgeColor', 'none'),set(gca, 'fontsize', fontsize_baselinea);
title('\textbf{Absolute error}','interpreter','latex','fontsize',fontsize_baselinet,'position',[0,0,1.45]),
colormap(jet(255));
view(25,25), axis vis3d, axis equal tight, colorbar('south'),clim([min(abs(pXYZR(:,2)-gXYZR)),max(abs(pXYZR(:,2)-gXYZR))]),
axis off



end