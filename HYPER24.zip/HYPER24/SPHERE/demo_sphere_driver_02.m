
function demo_sphere_driver_02

%--------------------------------------------------------------------------
% OBJECT.
% This function runs the experiments for hyperinterpolation over the unit
% sphere S2={(x,y,z): x^2+y^2+z^2=1}.
%
% Several hyperinterpolants are use on possibly noisy functions.
%
% It makes the following numerical experiments:
% a) Fixed noise and several well-chosen lambda parameters (where useful).
% b) Fixed lambda and variable noise.
%
% At the end of the code
% 1. it produces the pertinent Latex files, making the relavant table.
% 2. it plots graphics comparing sparsity and L2 err. on some hyp.variants.
% 3. it plots J(z), H(z), as in Thm.5 of the accompanying paper. 
%--------------------------------------------------------------------------
% In the paper "Hybrid hyperinterpolation over general regions", we
% consider:
%
% 1. f(x,y,z)=linear combination of Wendland RBF.
% 2. Maximum hyperinterpolant degree: 15 (rule: ade=30).
% 3. Reference cubature rule degree of precision: 50.
% 4. Experiment 1. Noise: a=0.02, sigma=0.02, lambda index=[5 50 100 200].
% 5. Experiment 2. Noise: a=[0.015 0.02 0.025 0.03],sigma=0,lambda index=50.
% 6. Experiment 3. Average Lambda: 5.202e-03.
% 7. Cubature points for hyperinterpolation: 482.
% 8. Cubature points for testing L2 errors: 1302.
% 9. Total amount of hyperinterpolation coefficients: 256.
%
% a) This routine runs the experiments cited in the paper above.
% b) The process took 104 seconds on a MacBook Pro, with Apple M1 processor
% and 16 GB of RAM (Stage 3 may be time consuming).
% c) Rules taken from: "Efficient Spherical Designs with Good Geometric
%   Properties".
%--------------------------------------------------------------------------
% Dates:
% Written on January 1, 2023: A. Sommariva.
% Modified on April 24, 2023: A. Sommariva.
% Joint work with Cong-Pei An, Jia-Shu Ran.
%--------------------------------------------------------------------------
% Reference paper:
% "Hybrid hyperinterpolation over general regions" 
% Congpei An · Alvise Sommariva · Jia-Shu Ran
%--------------------------------------------------------------------------
% COPYRIGHT
%--------------------------------------------------------------------------
% Copyright (C) 2023- 
%
% Authors:
% Alvise Sommariva
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <https://www.gnu.org/licenses/>.
%--------------------------------------------------------------------------


clear;

% ............................. SETTINGS ..................................

% a) PART 1: fixed noise
kV=[5 50 100 200];
a1=0.02; sigma1=0.02;

% b) PART 2: fixed lambda
kS=50; % lambda is choosen equal to the "k"-th hyp. coeff. in magnitude.
a2=0.02; sigma2V=[0.015 0.02 0.025 0.03]; % noise parameters

% c) PART 3: sparsity plots
kP=1:1:60;
a3=0.02; sigma3=0.02;





% ........................ main code below ................................



% .................... FIRST STAGE OF EXPERIMENTS   .......................

fprintf(2,'\n \n \n \t * <strong>Stage 1.</strong> \n \n \n ') 

tic;

AE2V=[]; betaV=[]; lambdaHIST=[];
XYZW=[]; XYZWR=[];

for k=kV
    % Technical note: Here we reuse the cub. rules once they are computes.
    [AEinf,AE2,beta,lambdaV,XYZW,XYZWR]=demo_sphere(k,a1,sigma1,XYZW,XYZWR);
    AE2V=[AE2V AE2]; betaV=[betaV beta]; lambdaHIST=[lambdaHIST lambdaV];
end

AE2T=AE2V(1,:); BETAT=betaV(1,:); % tikhonov data storage
AE2F=AE2V(2,:); BETAF=betaV(2,:); % filtered hyp. data storage
AE2L=AE2V(3,:); BETAL=betaV(3,:); % lasso hyp. data storage
AE2H=AE2V(4,:); BETAH=betaV(4,:); % Hybrid hyp. data storage
AE2HA=AE2V(5,:); BETAHA=betaV(5,:); % Hard hyp. data storage
AE20=AE2V(6,:); BETA0=betaV(6,:); % Hyp. data storage


% Making Matlab tables
AE2V1=AE2V; betaV1=betaV; BETAH1=BETAH;
HypType=categorical({'tikhonov'; 'filtered'; 'lasso'; 'hybrid'; 'hard'; ...
    'hyperint.'; 'hyb.spars.'});
tablemat=[AE2V1; BETAH1];
T = table(HypType,tablemat); disp(T);

fprintf('\n \t * Lambda interval (for hyp. variants): [%1.2e,%1.2e] \n',...
    min(min(lambdaHIST(kV,:))),max(max(lambdaHIST(kV,:))));

for k=1:length(kV)
    kVL=kV(k);
    fprintf('\n \t * Lambda %1.0f column (average): %1.4e',...
    k,mean(lambdaHIST(kVL,:)));
end



% ...................... SECOND STAGE OF EXPERIMENTS  .....................

fprintf(2,'\n \n \n \t * <strong>Stage 2.</strong> \n ') 
fprintf(2,'\n \n \t -> Average lambda: %1.3e \n \n',...
    mean(lambdaV(kS,:)));


% 2. Making experiments

AE2V=[]; betaV=[];

for sigma2=sigma2V
    [AEinf,AE2,beta,lambdaV,XYZW,XYZWR]=demo_sphere(kS,a2,sigma2,XYZW,XYZWR);
    AE2V=[AE2V AE2]; betaV=[betaV beta];
end

% 3. Making tables
AE2V2=AE2V; betaV2=betaV; BETAH2=betaV(4,:);
HypType=categorical({'tikhonov'; 'filtered'; 'lasso'; 'hybrid'; 'hard'; ...
    'hyperint.'; 'hyb.spars.'});
tablemat=[AE2V2; BETAH2];
T = table(HypType,tablemat); disp(T)




% ....................... PRODUCE LATEX TABLE  ............................

fprintf(2,'\n \n \t -> LaTeX table \n \n');

fileID=fopen('results_latex_unitsphere_stage1.txt','w');

strC={'Tikhonov'; 'Filtered'; 'Lasso'; 'Hybrid'; 'Hard'; 'Hyperint.'; ...
    '$\|{\mathbf{\beta}}\|_{0}$'};
for k=1:7
    strL=strC{k};

    strNUM='';

    for s=1:size(AE2V1,2)

        if k< 7
            strNUML=['$',num2str(AE2V1(k,s),'%.4f'),'$ &'];
        else
            strNUML=[ '$',num2str(BETAH1(s),'%.1f'),'$ &'];
        end

        strNUM=[strNUM strNUML];

    end


    for s=1:size(AE2V2,2)

        if k< 7
            strNUML=['$',num2str(AE2V2(k,s),'%.4f'),'$ &'];
        else
            strNUML=[ '$',num2str(BETAH2(s),'%.1f'),'$ &'];
        end

        strNUM=[strNUM strNUML];
        
    end

    if k ==7
        fprintf('\n \t'); disp('\hline');
        fprintf(fileID,'\n \t \\hline');
    end

    strNUM=[extractBefore(strNUM,length(strNUM)),'\\'];

    strdisp=['{\em{',strL,'}} &',strNUM];
    fprintf('\n \t '); disp(strdisp);

    strdispfile=replace(strdisp,'\','\\');
    fprintf(fileID,strcat('\n \t',' ',strdispfile));
end

fclose(fileID);








% ....................... THIRD STAGE OF EXPERIMENTS  .....................

fprintf(2,'\n \n \n \t * <strong>Stage 3.</strong> \n ') 

AE2P=[]; betaP=[]; JzHIST=[]; HzHIST=[];

% Making experiments.
for k=kP
    % fprintf('\n \t k: %3.0f',k)
    [AEinf,AE2,beta,lambdaV,XYZW,XYZWR,JzL,HzL,Wg_norm2]=demo_sphere(k,...
        a3,sigma3,XYZW,XYZWR);
    AE2P=[AE2P AE2]; betaP=[betaP beta];
    JzHIST=[JzHIST JzL]; HzHIST=[HzHIST HzL];
end



% .................... PLOT FIGURE SPARSITY vs L2 ERROR  ..................

fprintf(2,'\n \n \t -> Plotting sparsity/L2 errors figure. \n') 

figure
subplot(1,2,1)


plot(betaP(3,:),JzHIST(3,:),'*','linewidth',1.7,'markersize',15,'color','r'), box on, set(gca,'fontsize',16),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'), axis square,
hold on

plot(betaP(3,:),HzHIST(3,:),'+','linewidth',1.7,'markersize',15,'color','r'), box on, set(gca,'fontsize',16),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'), axis square,
hold on

plot(betaP(4,:),JzHIST(4,:),'o','linewidth',1,'markersize',33,'color','k'), box on, set(gca,'fontsize',16),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'), axis square,
hold on

plot(betaP(4,:),HzHIST(4,:),'s','linewidth',1,'markersize',33,'color','k'), box on, set(gca,'fontsize',16),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'), axis square,
hold on


plot(betaP(5,:),JzHIST(5,:),'d','linewidth',1.5,'markersize',20,'color','b'), box on, set(gca,'fontsize',16),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'), axis square,
hold on

%plot(betaP(5,:),HzHIST(5,:),'d','linewidth',2,'markersize',11,'MarkerFaceColor','b','color','b'), box on, set(gca,'fontsize',16),
plot(betaP(5,:),HzHIST(5,:),'^','linewidth',1.5,'markersize',20,'color','b'), box on, set(gca,'fontsize',16),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'), axis square,
hold on

yscale_symlog

legend({'Lasso (J)','Lasso (H)','Hybrid (J)','Hybrid (H)','Hard thresholding (J)','Hard thresholding (H)'},'interpreter','latex','fontsize',25);

xlabel({'Sparsity $(a)$'},'interpreter','latex','fontsize',25);ylabel({'Values'},'interpreter','latex','fontsize',25);
grid on;
%set(gca,'position',[0.04 0.05 0.45 0.9])

subplot(1,2,2)



semilogy(betaP(3,:),AE2P(3,:),'r*','linewidth',1,'markersize',19),box on, set(gca,'fontsize',16),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'),axis square,
hold on
semilogy(betaP(4,:),AE2P(4,:),'ko','linewidth',2,'markersize',25),box on, set(gca,'fontsize',16),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'),axis square,
hold on
semilogy(betaP(5,:),AE2P(5,:),'bd','linewidth',1.5,'markersize',21),box on, set(gca,'fontsize',16),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'),axis square,
hold on

legend({'Lasso', 'Hybrid', 'Hard thresholding'},'interpreter','latex','fontsize',25);

xlabel({'Sparsity $(b)$'},'interpreter','latex','fontsize',25);ylabel({'$L_2$ Errors'},'interpreter','latex','fontsize',25);
grid on;
%set(gca,'position',[0.53 0.05 0.45 0.9])