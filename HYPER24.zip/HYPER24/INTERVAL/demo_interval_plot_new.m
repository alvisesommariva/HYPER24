function demo_interval_plot_new

clear all;clc;
[X,gX,gX_pert,gXR,XR,idx_all,idx_infity,coeff0,LV,VR,WR,W,pert]=demo_interval_plot_error;


lambdas = -15:0.1:7;

lambdaL=2.^lambdas;

degs=0:LV;

for ktest=1:6
            switch ktest
                case 1
                    hypermode='tikhonov';
                    parms.lambda=lambdaL(idx_infity(1));
                    parms.mu=[];
                    parms.b=ones(size(coeff0));
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);

                case 2
                    hypermode='filtered';
                    parms.lambda=[];
                    parms.mu=[];
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 3
                    hypermode='lasso';
                    parms.lambda=lambdaL(idx_infity(2));
                    parms.mu=ones(size(coeff));
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 4
                    hypermode='hybrid';
                    parms.lambda=lambdaL(idx_infity(3));
                    parms.mu=ones(size(coeff0));
                    parms.b=ones(size(coeff0));
                    parms.w=W;
                    parms.pert=pert;
                    parms.hybrid=0; % establishes it is a pre-choosen parameter.
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
              case 5
                    hypermode='hard';
                    parms.lambda=lambdaL(idx_infity(1));
                    parms.mu=[];
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 6
                    hypermode='hyperinterpolation';
                    parms.lambda=[];
                    parms.mu=[];
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
            end

            %gXR=feval(g,XR);
            %VR=vandermonde_gausslegendre(LV,XR);
            pXR(:,ktest)=VR*coeff;



            % errors
            AEinfV(ktest)=norm(gXR-pXR(:,ktest),inf); % absolute error (inf norm)
            AE2V(ktest)=sqrt(WR'*((gXR-pXR(:,ktest)).^2)); % absolute error (2 norm)
            beta0V(ktest)=sum(abs(coeff) > 0);        

end


%% Plot
figure(4)
fontsize_baseline = 35;
fontsize_baselinet = 30;
fontsize_baselinea = 35;

%Primal and noisy function
subplot(2,4,1)
%axes('position',[0.075 0.55 0.2 0.4]), 
plot(X,gX,'linewidth',2,'color','k'), box on,...
    set(gca, 'fontsize', fontsize_baselinea),...
    xlabel('$x$','interpreter','latex', 'fontsize', fontsize_baseline),...%ylabel('$f(x)$','interpreter','latex', 'fontsize', fontsize_baseline),...
    title('\textbf{Original function} $f$','interpreter','latex','fontsize',fontsize_baselinet),...
     grid on,...
     set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'),axis([-1,1,0,1.5]),
subplot(2,4,5)
%axes('position',[0.075 0.05 0.2 0.4]), 
plot(X,gX_pert,'linewidth',2,'color','k'),box on,...
    set(gca, 'fontsize', fontsize_baselinea),...
    xlabel('$x$','interpreter','latex', 'fontsize', fontsize_baseline),...%ylabel('$f(x)$','interpreter','latex', 'fontsize', fontsize_baseline),...
    title('\textbf{Noisy function} $f^{\epsilon}$','interpreter','latex','fontsize', fontsize_baselinet),...
     grid on,...
     set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'),axis([-1,1,0,1.5]),

% hyper. and its error
subplot(2,4,2)
%axes('position',[0.3 0.55 0.2 0.4]),
plot(XR,pXR(:,6),'linewidth',2,'color','k'), box on,...
    set(gca, 'fontsize', fontsize_baselinea),...
    xlabel('$x$','interpreter','latex', 'fontsize', fontsize_baseline),...%ylabel('$f(x)$','interpreter','latex', 'fontsize', fontsize_baseline),...
    %title('\textbf{Hyperinterpolation}', 'interpreter','latex','fontsize', fontsize_baselinet),  grid on,...
    title('$\mathcal{L}_L f^{\epsilon}$', 'interpreter','latex','fontsize', fontsize_baselinet),  grid on,...
     set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'),axis([-1,1,0,1.5]),
%axes('position',[0.3 0.05 0.2 0.4]), 
subplot(2,4,6)
plot(XR,abs(gXR-pXR(:,6)),'linewidth',2,'color','k'),set(gca, 'fontsize', fontsize_baselinea),...
    xlabel('$x$','interpreter','latex', 'fontsize', fontsize_baseline),...%ylabel('Absolute error', 'interpreter','latex','fontsize', fontsize_baseline),...
    title('\textbf{Absolute error}','interpreter','latex','fontsize', fontsize_baselinet),box on, grid on,...
     set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'),axis([-1,1,0,1]),

% filtered hyper. and its error
%axes('position',[0.525 0.55 0.2 0.4]),
subplot(2,4,3)
plot(XR,pXR(:,2),'linewidth',2,'color','k'), box on,...
    set(gca, 'fontsize', fontsize_baselinea),...
    xlabel('$x$','interpreter','latex', 'fontsize', fontsize_baseline),...%ylabel('$f(x)$','interpreter','latex', 'fontsize', fontsize_baseline),...
    %title(['$\mathcal{E}_L^{\lambda} f^{\epsilon}$ \textbf{with} $\lambda=$',num2str(lambdaL(idx_infity(1)))], 'interpreter','latex','fontsize', fontsize_baselinet),  grid on,...
    title('$\mathcal{F}_{L,N} f^{\epsilon}$', 'interpreter','latex','fontsize', fontsize_baselinet),  grid on,...
     set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'),axis([-1,1,0,1.5]),
%axes('position',[0.525 0.05 0.2 0.4]), 
subplot(2,4,7)
plot(XR,abs(gXR-pXR(:,2)),'linewidth',2,'color','k'),set(gca, 'fontsize', fontsize_baselinea),...
    xlabel('$x$','interpreter','latex', 'fontsize', fontsize_baseline),...%ylabel('Absolute error', 'interpreter','latex','fontsize', fontsize_baseline),...
    title('\textbf{Absolute error}','interpreter','latex','fontsize', fontsize_baselinet),box on, grid on,...
     set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'),axis([-1,1,0,1]),

%hybrid hyper. and its error
%axes('position',[0.75 0.55 0.2 0.40]),
subplot(2,4,4)
plot(XR,pXR(:,4),'linewidth',2,'color','k'),box on,set(gca, 'fontsize', fontsize_baselinea), ...
     xlabel('$x$','interpreter','latex', 'fontsize', fontsize_baseline),...%ylabel('$f(x)$','interpreter','latex', 'fontsize', fontsize_baseline),...
title(['$\mathcal{H}_L^{\lambda} f^{\epsilon}$ \textbf{with} $\lambda=$',num2str(lambdaL(idx_infity(3)))], 'interpreter','latex','fontsize', fontsize_baselinet),  grid on,...
     set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'),axis([-1,1,0,1.5]),
%axes('position',[0.75 0.05 0.2 0.40]), 
subplot(2,4,8)
plot(XR,abs(gXR-pXR(:,4)),'linewidth',2,'color','k'),set(gca, 'fontsize', fontsize_baselinea), xlabel('$x$','interpreter','latex', 'fontsize', fontsize_baseline),...%ylabel('Absolute error','interpreter','latex', 'fontsize', fontsize_baseline),...
    title('\textbf{Absolute error}','interpreter','latex','fontsize', fontsize_baselinet),box on,grid on,...
     set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'),axis([-1,1,0,1]),



end