function [X,gX,gX_pert,gXR,XR,idx_all,idx_infity,coeff0,LV,VR,WR,W,pert]=demo_interval_plot_error
% Codes based on Alvise Sommariva (University of Padova)
% Date: 14 August, 2023
% demo_interval_plot is used to plot original function
% and its recovery function via different hyperinterpolants
% on the interval [-1,1]

%--------------------------------------------------------------------------
% Degrees of precision in numerical experiments: can be a vector.
%-------------------------------------------------------------------------
LV=250;      % Hyperinterpolant total degree.
NV=251;     % Points of the rule used for hyperintepolation. 
NR=300;     % Points used by the reference rule (testing L2 errors).


%--------------------------------------------------------------------------
% Noise and choice of lasso, hybrid, hard thresh. parameter.
%--------------------------------------------------------------------------



% No table or stats.
display_stats=1;

% * Function to approximate (see approx. line 312):
funct_example=3; % set 1 or 2 for polynomials of degree L or L/2 (approx.)


% ........................ Main code below ................................

% vectors used for statistics
AEinfMV=[]; AE2MV=[]; beta0MV=[]; 

% Test points
XWR=quad_gausslegendre(NR); XR=XWR(:,1); WR=XWR(:,2);

% define quadrature rule for hyperinterpolation at degree NV.
XW=quad_gausslegendre(NV); X=XW(:,1); W=XW(:,2);

% Vandermonde matrix at nodes.
V=vandermonde_gausslegendre(LV,X);

poly_coeffs=[];
lambdaV=[];

% ... define function to approximate ...
g=define_function(funct_example,LV);

% ... evaluate function to approximate ...
gX=feval(g,X);


sigma = 0.1;

% add gaussian noise
pert = sigma*randn(size(gX));


% perturbed values
gX_pert=gX+pert;

% ... determine polynomial hyperinterpolant ...
coeff0=(gX_pert.*W)'*V; coeff0=coeff0';


% we reference to the method in "RBF approximation of noisy scattered data on the sphere"
lambdas = -15:0.1:7;

lambdak=2.^lambdas;

for k = 1:length(lambdas)
lambdaL = lambdak(k);

degs=0:LV;

for ktest=1:6
            switch ktest
                case 1
                    hypermode='tikhonov';
                    parms.lambda=lambdaL;
                    parms.mu=[];
                    parms.b=ones(size(coeff0));
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);

                case 2
                    hypermode='filtered';
                    parms.lambda=[];
                    parms.mu=[];
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 3
                    hypermode='lasso';
                    parms.lambda=lambdaL;
                    parms.mu=ones(size(coeff));
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 4
                    hypermode='hybrid';
                    parms.lambda=lambdaL;
                    parms.mu=ones(size(coeff0));
                    parms.b=ones(size(coeff0));
                    parms.w=W;
                    parms.pert=pert;
                    parms.hybrid=0; % establishes it is a pre-choosen parameter.
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
              case 5
                    hypermode='hard';
                    parms.lambda=lambdaL;
                    parms.mu=[];
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 6
                    hypermode='hyperinterpolation';
                    parms.lambda=[];
                    parms.mu=[];
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
            end

            gXR=feval(g,XR);
            VR=vandermonde_gausslegendre(LV,XR);
            pXR(:,ktest)=VR*coeff;



            % errors
            AEinfV(k,ktest)=norm(gXR-pXR(:,ktest),inf);      % absolute error (inf norm)
            AE2V(k,ktest)=sqrt(WR'*((gXR-pXR(:,ktest)).^2)); % absolute error (2 norm)
            beta0V(k,ktest)=sum(abs(coeff) > 0);
   
         
end

end


%% Plot

% hard thresholding hyper.
figure(1)
[xmin_hth, ] = find(AE2V(:,5) == min(AE2V(:,5)));
[xmin_hth_infity, ] = find(AEinfV(:,5) == min(AEinfV(:,5)));
subplot(2,1,1)
loglog(lambdak,AE2V(:,5),'linewidth',1,'color','blue'), box on, set(gca,'fontsize',16),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'),
hold on
loglog(lambdak(xmin_hth),min(AE2V(:,5)),'pentagram','linewidth',2,'MarkerSize',20,'color','red','MarkerFaceColor','red'), hold on,

xlabel({'\textbf{Smoothing parameter} $\lambda$'},'interpreter','latex','fontsize',30);
legend({'$L_2$ \textbf{norm of error}',['{\textbf{Minimum at}} $\lambda \in [$',num2str(min(lambdak(xmin_hth))),'$,\:$', num2str(max(lambdak(xmin_hth))),'$]$']},'interpreter','latex','fontsize',25);
title({'\textbf{Hard thresholding hyperinterpolation}'},'interpreter','latex','fontsize',35);

subplot(2,1,2)
loglog(lambdak,AEinfV(:,5),'linewidth',1,'color','black'), box on, set(gca,'fontsize',16),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'),
hold on
loglog(lambdak(xmin_hth_infity),min(AEinfV(:,5)),'diamond','linewidth',2,'MarkerSize',15,'color','red','MarkerFaceColor','red'), hold on,

xlabel({'\textbf{Smoothing parameter} $\lambda$'},'interpreter','latex','fontsize',30);
legend({'$L_{\infty}$ \textbf{norm of error}',['{\textbf{Minimum at}} $\lambda \in [$',num2str(min(lambdak(xmin_hth_infity))),'$,\:$', num2str(max(lambdak(xmin_hth_infity))),'$]$']},'interpreter','latex','fontsize',25);

% lasso hyper.
figure(2)
[xmin_lh, ] = find(AE2V(:,3) == min(AE2V(:,3)));
[xmin_lh_infity, ] = find(AEinfV(:,3) == min(AEinfV(:,3)));
subplot(2,1,1)
loglog(lambdak,AE2V(:,3),'linewidth',1,'color','blue'), box on, set(gca,'fontsize',16),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'),
hold on
loglog(lambdak(xmin_lh),min(AE2V(:,3)),'pentagram','linewidth',1,'MarkerSize',20,'color','red','MarkerFaceColor','red'), hold on,

xlabel({'\textbf{Smoothing parameter} $\lambda$'},'interpreter','latex','fontsize',30);
legend({'$L_2$ \textbf{norm of error}',['{\textbf{Minimum at}} $\lambda=$',num2str(lambdak(xmin_lh))]},'interpreter','latex','fontsize',25);

title({'\textbf{Lasso hyperinterpolation}'},'interpreter','latex','fontsize',35);

subplot(2,1,2)
loglog(lambdak,AEinfV(:,3),'linewidth',1,'color','black'), box on, set(gca,'fontsize',16),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'),%axis([0,TT-1,-1.5,0.5]),
hold on
loglog(lambdak(xmin_lh_infity),min(AEinfV(:,3)),'diamond','linewidth',1,'MarkerSize',15,'color','red','MarkerFaceColor','red'), hold on,

xlabel({'\textbf{Smoothing parameter} $\lambda$'},'interpreter','latex','fontsize',30);
legend({'$L_{\infty}$ \textbf{norm of error}',['{\textbf{Minimum at}} $\lambda=$',num2str(lambdak(xmin_lh_infity))]},'interpreter','latex','fontsize',25);


% hybrid hyper.
figure(3)

[xmin_hh, ] = find(AE2V(:,4) == min(AE2V(:,4)));
[xmin_hh_infity, ] = find(AEinfV(:,4) == min(AEinfV(:,4)));


loglog(lambdak,AE2V(:,4),'linewidth',3,'color','blue'), box on, 
set(gca, 'FontSize', 35, 'XMinorGrid', 'on'), set(gca, 'FontSize', 35, 'YMinorGrid', 'on'),
hold on,
loglog(lambdak,AEinfV(:,4),'-.','linewidth',3,'color','black'), box on, 
set(gca, 'FontSize', 35, 'XMinorGrid', 'on'), set(gca, 'FontSize', 35, 'YMinorGrid', 'on'),
loglog(lambdak(xmin_hh),min(AE2V(:,4)),'pentagram','linewidth',2,'MarkerSize',30,'color','red','MarkerFaceColor','red'), hold on,
loglog(lambdak(xmin_hh_infity),min(AEinfV(:,4)),'diamond','linewidth',2,'MarkerSize',30,'color','red','MarkerFaceColor','red'), hold on,


title({'\textbf{Hybrid hyperinterpolation}'},'interpreter','latex','fontsize',35);
xlabel({'\textbf{Smoothing parameter} $\lambda$'},'interpreter','latex','fontsize',35);
legend({'$L_2$ \textbf{norm of error}','$L_{\infty}$ \textbf{norm of error}',['{\textbf{Minimum at}} $\lambda=$',num2str(lambdak(xmin_hh))],['{\textbf{Minimum at}} $\lambda=$',num2str(lambdak(xmin_hh_infity))]},'interpreter','latex','fontsize',40,'Location','northwest');


idx_all = [min(xmin_hth),xmin_lh,xmin_hh];
idx_infity = [min(xmin_hth_infity),xmin_lh_infity,xmin_hh_infity];

sparsity_all = [beta0V(min(xmin_hth),1),beta0V(1,2),beta0V(xmin_lh,3),beta0V(xmin_hh,4),beta0V(min(xmin_hth),5),beta0V(1,6)];

sparsity_infity = [beta0V(min(xmin_hth_infity),1),beta0V(1,2),beta0V(xmin_lh_infity,3),beta0V(xmin_hh_infity,4),beta0V(min(xmin_hth_infity),5),beta0V(1,6)];


lambdaL = lambdak;

fprintf("....Variants.....lambda.....smallest $L_2$ error.....sparsity.....lambda.....smallest maximum error.....sparsity.....\n")
fprintf("{\\em{Hyperint.}} & $ - $ & $ %.6f $ & $ %d $ & $ - $ & $%.6f$ & $%d$ \n",AE2V(6,6),sparsity_all(6),AEinfV(6,6),sparsity_infity(6))
fprintf("\n")
fprintf("{\\em{Filtered}} & $ - $ & $ %.6f $ & $ %d $ & $ - $ & $%.6f$ & $%d$ \n", AE2V(2,2),sparsity_all(2),AEinfV(2,2),sparsity_infity(2))
fprintf("\n")
fprintf("{\\em{Lasso}} & $ %.6f $ & $ %.6f $ & $ %d $ & $ %.6f $ & $%.6f$ & $%d$ \n",lambdaL(idx_all(2)),AE2V(idx_all(2),3),sparsity_all(3),lambdaL(idx_infity(2)),AEinfV(idx_infity(2),3),sparsity_infity(3))
fprintf("\n")
fprintf("{\\em{Hybrid}} & $ %.6f $ & $ %.6f $ & $ %d $ & $ %.6f $ & $%.6f$ & $%d$ \n",lambdaL(idx_all(3)),AE2V(idx_all(3),4),sparsity_all(4),lambdaL(idx_infity(3)),AEinfV(idx_infity(3),4),sparsity_infity(4))
fprintf("\n")
fprintf("{\\em{Hard}} & $ %.6f $ & $ %.6f $ & $ %d $ & $ %.6f $ & $%.6f$ & $%d$ \n",lambdaL(idx_all(1)),AE2V(idx_all(1),5),sparsity_all(5),lambdaL(idx_infity(1)),AEinfV(idx_infity(1),5),sparsity_infity(5))
fprintf("\n")



end


%% ATTACHED ROUTINES.

function sgn_coeff = sgnfun(coeff0)

for k=1:length(coeff0)
    if coeff0(k) > 0
        sgn_coeff(k) = 1;
    elseif coeff0(k) < 0
        sgn_coeff(k) = -1;
    else
        sgn_coeff(k) = 0;
    end
end

end


function XW=quad_gausslegendre(n)

%--------------------------------------------------------------------------
% Object:
% Gauss Legendre rule on the unit interval [-1,1].
% * Important: ade=2*n-1
%--------------------------------------------------------------------------
% Input:
% n: cardinality of the Gaussian rule
%--------------------------------------------------------------------------
% Output:
% XW: n x 2 matrix, where XW(:,1) are the nodes and XW(:,2) are the
%    weights.
%--------------------------------------------------------------------------

% Gaussian rule in [-1,1]: ade=2*n -> n+1 points.
ab=r_jacobi(n+1,0,0); XW=gauss(n+1,ab);

end



function plot_error(f,coeff,n)

XR=-1:0.01:1; XR=XR';

fXR=feval(f,XR);
VR=vandermonde_gausslegendre(n,XR);
pXR=VR*coeff;
aerr=abs(fXR-pXR);
rerr=aerr./abs(fXR);

semilogy(XR,rerr);

end




function V=vandermonde_gausslegendre(deg,x)

%--------------------------------------------------------------------------
% Object:
% Orthonormal Gauss-Legendre Vandermonde matrix.
% This basis is numerically almost orthonormal even at high degrees.
%--------------------------------------------------------------------------
% Input:
% deg: degree of the polynomial basis;
% x  : M points in which the basis is evaluated.
%--------------------------------------------------------------------------
% Output:
% V  : Vandermonde matrix of degree "deg" at "x". It is a "(deg+1) x M"
%      matrix.
%--------------------------------------------------------------------------

V=ones(size(x));

if deg >= 1
    V=[V x];
end

for n=1:deg-1
    VO=V(:,end); VOO=V(:,end-1);
    VL=((2*n+1)*x.*VO-n*VOO)/(n+1);
    V=[V VL];
end

N=0:deg;
s=1./sqrt(2./(2*N+1));
S=repmat(s,size(V,1),1);
V=V.*S;

end



function g=define_function(funct_example,L)

%--------------------------------------------------------------------------
% Object:
% Define function to be tested.
%--------------------------------------------------------------------------
% Input:
% funct_example: parameter defining the function to be tested
%                1: random polynomial of form (c0+c1*x)^L.
%                2: random polynomial of form (c0+c1*x)^n with
%                   n=max(floor(L/2)-1,0).
%                3: exp(-x^2)
%--------------------------------------------------------------------------
% Output:
% g: function to test.
%--------------------------------------------------------------------------


switch funct_example

    case 1 % test exactness hyperinterpolation
        nexp=L;
        c0=rand(1); c1=rand(1);
        g=@(x) (c0+c1*x).^nexp;

    case 2 % test exactness filt. hyperinterpolation
        nexp=max(floor(L/2)-1,0);
        c0=rand(1); c1=rand(1); c2=rand(1);
        g=@(x) (c0+c1*x).^nexp;

    case 3 % function of that type

        %  Test function "exp(-x.^2)" has been choosen on the Lasso
        %  paper.

        funct_example_sub=2;

        switch funct_example_sub
            case 1
                g=@(x) exp(-2*x); fstring='exp(-2*x)';
            case 2
                g=@(x) exp(-x.^2); fstring='exp(-x.^2)';
                %g=@(x) 4*(x.^5).*sin(10*x); fstring = '4*(x.^5).*sin(10*x)';
            case 3
                g=@(x) cos(-x.*2); fstring='cos(-x.*2)';
            case 4
                g=@(x) sin(x)+x.^2; fstring='sin(x)+x.^2';
        end

    case 4
        g=@(x) 1./(1+25*x.^2);
end



end